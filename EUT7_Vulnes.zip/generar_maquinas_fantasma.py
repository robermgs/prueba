r"""
Detecta máquinas "fantasma": llevan --umbral-dias (por defecto 30) días o
más sin actividad reportada a Qualys, pero siguen apareciendo en el CSV
(y por tanto contando en los totales) como si estuvieran activas. Suele
ser indicio de equipos dados de baja/reemplazados que nadie ha quitado
del scan.

Uso:
    python3 generar_maquinas_fantasma.py SA.csv SG.csv 2026-09-03 \
        --umbral-dias 30 --out ..\resumenes\maquinas_fantasma_2026-09-03.txt
"""
import argparse
import sys

from core import cargar_datos, tabla_maquinas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--umbral-dias', type=int, default=30)
    ap.add_argument('--out', default='maquinas_fantasma.txt')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas, fecha_informe=args.fecha)

    fantasma = [m for m in mt if m['dias_sin_reportar'] is not None and m['dias_sin_reportar'] >= args.umbral_dias]
    fantasma.sort(key=lambda m: -m['dias_sin_reportar'])

    print(f'{len(fantasma)} máquina(s) llevan {args.umbral_dias}+ días sin reportar '
          f'(de {len(mt)} máquinas totales).')

    lineas = [
        f'MÁQUINAS FANTASMA · EUT Vulnes · {args.fecha}',
        f'(llevan {args.umbral_dias} días o más sin actividad reportada a Qualys, '
        f'pero siguen contando como activas)',
        '=' * 70,
        '',
    ]
    if not fantasma:
        lineas.append('Ninguna — todo lo que cuenta como activo ha reportado recientemente. 👍')
    for m in fantasma:
        lineas.append(f"  {m['dias_sin_reportar']:>4} días  {m['machine']:<20} "
                       f"{m['ent']}/{m['sub']:<20}  {m['count']} vulns · última actividad: {m['activity'] or '(desconocida)'}")

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())
