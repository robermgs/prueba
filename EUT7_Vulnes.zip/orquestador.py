r"""
Orquestador diario de EUT Vulnes. Ejecuta todos los scripts en orden y,
al final, muestra un resumen tipo "OK 9 de 9 pasos" o la lista de qué
ha fallado — en vez de tener que leer toda la pantalla negra para
enterarte.

Solo el chequeo de calidad puede DETENER la ejecución (si el CSV viene
gravemente mal, ej. prácticamente vacío). El resto de pasos, si fallan,
se anotan en el resumen final pero se sigue con los demás — así un fallo
puntual en un informe secundario no te deja sin el resto de paneles.

Uso (normalmente lo llama run_diario.bat, no hace falta usarlo a mano):
    python orquestador.py [FECHA]
"""
import os
import subprocess
import sys
from datetime import datetime

AQUI = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(AQUI)
CSV = os.path.join(BASE, 'csv_diarios')
HIST = os.path.join(BASE, 'historico')
DASH = os.path.join(BASE, 'dashboards')
RES = os.path.join(BASE, 'resumenes')

SA = os.path.join(CSV, 'SA.csv')
SG = os.path.join(CSV, 'SG.csv')

resultados = []  # (nombre, ok: bool)


def ejecutar(nombre, args, critico=False):
    print(f'\n=== {nombre} ===')
    r = subprocess.run([sys.executable] + args)
    ok = r.returncode == 0
    resultados.append((nombre, ok))
    if not ok:
        print(f'*** "{nombre}" ha fallado (codigo {r.returncode}) ***')
        if critico:
            print('*** Es un paso critico: se detiene la ejecucion. ***')
            resumen_final()
            sys.exit(1)
    return ok


def resumen_final():
    total = len(resultados)
    ok = sum(1 for _, o in resultados if o)
    print()
    print('=' * 50)
    if ok == total:
        print(f'OK: {ok} de {total} pasos correctos. Todo bien.')
    else:
        print(f'AVISO: {ok} de {total} pasos correctos. Han fallado:')
        for nombre, o in resultados:
            if not o:
                print(f'    - {nombre}')
    print('=' * 50)


def detectar_fecha(fecha_arg):
    script = os.path.join(AQUI, 'preparar_csv_dia.py')
    args = [sys.executable, script, CSV]
    if fecha_arg:
        args += ['--fecha', fecha_arg]
    r = subprocess.run(args, capture_output=True, text=True)
    fecha = r.stdout.strip()
    if r.returncode == 0 and fecha:
        print(r.stderr, end='')
        return fecha
    print('No se han encontrado CSV con nombre YYYYMMDD_Critical_SANTEC/SGTO.csv en csv_diarios.')
    print('Se usaran los SA.csv/SG.csv que ya tengas puestos a mano ahi.')
    return fecha_arg or datetime.now().strftime('%Y-%m-%d')


def main():
    fecha_arg = sys.argv[1] if len(sys.argv) > 1 else None
    fecha = detectar_fecha(fecha_arg)

    print('=' * 42)
    print(f' Generando paneles EUT Vulnes para {fecha}')
    print('=' * 42)

    os.makedirs(RES, exist_ok=True)

    ejecutar('Backup', [os.path.join(AQUI, 'backup_historico.py'), HIST, CSV, fecha])

    ejecutar('Chequeo de calidad', [
        os.path.join(AQUI, 'chequeo_calidad.py'), SA, SG, fecha,
        '--baseline', os.path.join(HIST, 'baseline_calidad.json'),
    ], critico=True)

    ejecutar('dashboard_resumen.html', [
        os.path.join(AQUI, 'generar_resumen.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_resumen.html'),
        '--historico', os.path.join(HIST, 'historico_resumen.json'),
        '--out', os.path.join(DASH, 'dashboard_resumen.html'),
    ])

    ejecutar('dashboard_vulnerabilidades.html', [
        os.path.join(AQUI, 'generar_vulnerabilidades.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_vulnerabilidades.html'),
        '--historico', os.path.join(HIST, 'historico_vulnerabilidades.json'),
        '--out', os.path.join(DASH, 'dashboard_vulnerabilidades.html'),
    ])

    ejecutar('dashboard_maquinas_desalineadas.html', [
        os.path.join(AQUI, 'generar_maquinas_desalineadas.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_maquinas_desalineadas.html'),
        '--historico', os.path.join(HIST, 'historico_desalineadas.json'),
        '--out', os.path.join(DASH, 'dashboard_maquinas_desalineadas.html'),
    ])

    ejecutar('dashboard_no_overdue.html', [
        os.path.join(AQUI, 'generar_no_overdue.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_no_overdue.html'),
        '--historico', os.path.join(HIST, 'historico_no_overdue.json'),
        '--out', os.path.join(DASH, 'dashboard_no_overdue.html'),
    ])

    ejecutar('dashboard_overdue_json.html', [
        os.path.join(AQUI, 'generar_overdue_json.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_overdue_json.html'),
        '--out', os.path.join(DASH, 'dashboard_overdue_json.html'),
    ])

    ejecutar('dashboard_vuln_detalle.html', [
        os.path.join(AQUI, 'generar_vuln_detalle.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_vuln_detalle.html'),
        '--historico', os.path.join(HIST, 'historico_vuln_detalle.json'),
        '--out', os.path.join(DASH, 'dashboard_vuln_detalle.html'),
    ])

    ejecutar('dashboard_maquina_detalle.html', [
        os.path.join(AQUI, 'generar_maquina_detalle.py'), SA, SG,
        os.path.join(CSV, 'Equipos_VIP.csv'), os.path.join(CSV, 'Estado_vulnes_1.csv'), fecha,
        '--template', os.path.join(DASH, 'dashboard_maquina_detalle.html'),
        '--historico', os.path.join(HIST, 'historico_maquina_detalle.json'),
        '--out', os.path.join(DASH, 'dashboard_maquina_detalle.html'),
    ])

    ejecutar('dashboard_resumen_entidades.html', [
        os.path.join(AQUI, 'generar_resumen_entidades.py'), SA, SG, fecha,
        '--template', os.path.join(DASH, 'dashboard_resumen_entidades.html'),
        '--out', os.path.join(DASH, 'dashboard_resumen_entidades.html'),
    ])

    ok_prior = ejecutar('Priorizacion (OPERATIVA/DIRECCION/PUBLICA)', [
        os.path.join(AQUI, 'generar_priorizacion.py'), SA, SG,
        os.path.join(CSV, 'Equipos_VIP.csv'), fecha,
        '--historico', os.path.join(HIST, 'historico_priorizacion.json'),
        '--template-operativa', os.path.join(DASH, 'priorizacion_OPERATIVA.html'),
        '--template-direccion', os.path.join(DASH, 'priorizacion_DIRECCION.html'),
        '--template-publica', os.path.join(DASH, 'priorizacion_PUBLICA.html'),
        '--outdir', DASH,
    ])
    if ok_prior:
        for nombre in ('OPERATIVA', 'DIRECCION', 'PUBLICA'):
            nuevo = os.path.join(DASH, f'priorizacion_{nombre}_NUEVO.html')
            final = os.path.join(DASH, f'priorizacion_{nombre}.html')
            if os.path.exists(nuevo):
                os.replace(nuevo, final)

    ejecutar('dashboard_recurrencia_software.html', [
        os.path.join(AQUI, 'generar_recurrencia_software.py'),
        '--historico-vulns', os.path.join(HIST, 'historico_vulnerabilidades.json'),
        '--template', os.path.join(DASH, 'dashboard_recurrencia_software.html'),
        '--out', os.path.join(DASH, 'dashboard_recurrencia_software.html'),
    ])

    ejecutar('Resumen ejecutivo + evolutivo Teams', [
        os.path.join(AQUI, 'generar_resumen_ejecutivo.py'), fecha,
        '--historico', os.path.join(HIST, 'historico_resumen.json'),
        '--outdir', RES,
    ])

    ejecutar('Tabla de seguimiento para Teams', [
        os.path.join(AQUI, 'generar_tabla_teams.py'), SA, SG,
        os.path.join(CSV, 'Estado_vulnes_1.csv'), fecha,
        '--historico-vulns', os.path.join(HIST, 'historico_vulnerabilidades.json'),
        '--out', os.path.join(RES, f'tabla_teams_{fecha}.html'),
    ])

    ejecutar('Cruce de fixed / transiciones overdue', [
        os.path.join(AQUI, 'generar_resumen_fixed.py'), SA, SG, fecha,
        '--snapshot', os.path.join(HIST, 'snapshot_vulnes.json'),
        '--out-maquinas', os.path.join(RES, f'resumen_maquinas_fixed_{fecha}.csv'),
        '--out-vulnes', os.path.join(RES, f'resumen_vulnes_fixed_{fecha}.csv'),
        '--out-transiciones', os.path.join(RES, f'transiciones_overdue_{fecha}.csv'),
    ])

    ejecutar('dashboard_bruto.html', [
        os.path.join(AQUI, 'generar_bruto.py'), SA, SG, fecha,
        '--historico', os.path.join(HIST, 'historico_bruto.json'),
        '--out', os.path.join(DASH, 'dashboard_bruto.html'),
    ])

    ejecutar('Limpieza de Estado_vulnes_1.csv', [
        os.path.join(AQUI, 'limpiar_estado_vulnes.py'), SA, SG,
        os.path.join(CSV, 'Estado_vulnes_1.csv'), fecha,
        '--archivo', os.path.join(HIST, 'estado_vulnes_archivado.csv'),
    ])

    ejecutar('Tickets olvidados', [
        os.path.join(AQUI, 'generar_tickets_olvidados.py'), os.path.join(CSV, 'Estado_vulnes_1.csv'), fecha,
        '--umbral-dias', '7',
        '--out', os.path.join(RES, f'tickets_olvidados_{fecha}.txt'),
    ])

    ejecutar('Ranking de entidades', [
        os.path.join(AQUI, 'generar_ranking_entidades.py'), SA, SG, fecha,
        '--out', os.path.join(RES, f'ranking_entidades_{fecha}.txt'),
    ])

    ejecutar('Rotacion de resumenes', [
        os.path.join(AQUI, 'rotar_resumenes.py'), RES, fecha, '--dias-retener', '60',
    ])

    ejecutar('Informe de cumplimiento SLA', [
        os.path.join(AQUI, 'generar_informe_sla.py'), RES, fecha,
        '--out', os.path.join(RES, f'informe_sla_{fecha}.txt'),
    ])

    ejecutar('Deteccion de vulnerabilidades zombi', [
        os.path.join(AQUI, 'generar_zombis.py'), os.path.join(HIST, 'historico_vulnerabilidades.json'), fecha,
        '--out', os.path.join(RES, f'vulnerabilidades_zombi_{fecha}.txt'),
    ])

    ejecutar('Indice de busqueda global', [
        os.path.join(AQUI, 'generar_indice_busqueda.py'), SA, SG, fecha,
        '--out', os.path.join(DASH, 'indice_busqueda.js'),
    ])

    ejecutar('Proximas a entrar en overdue', [
        os.path.join(AQUI, 'generar_proximos_overdue.py'), SA, SG, fecha,
        '--margen-dias', '5',
        '--out', os.path.join(RES, f'proximos_overdue_{fecha}.txt'),
    ])

    ejecutar('Proyeccion de tendencia overdue', [
        os.path.join(AQUI, 'generar_proyeccion.py'), os.path.join(HIST, 'historico_resumen.json'), fecha,
        '--dias-ventana', '7',
        '--out', os.path.join(RES, f'proyeccion_overdue_{fecha}.txt'),
    ])

    ejecutar('Maquinas fantasma', [
        os.path.join(AQUI, 'generar_maquinas_fantasma.py'), SA, SG, fecha,
        '--umbral-dias', '30',
        '--out', os.path.join(RES, f'maquinas_fantasma_{fecha}.txt'),
    ])

    ejecutar('Fechas exactas de entrada en overdue', [
        os.path.join(AQUI, 'generar_fechas_overdue.py'), SA, SG, fecha,
        '--out', os.path.join(RES, f'fechas_entrada_overdue_{fecha}.csv'),
    ])

    resumen_final()
    print(f'\nPaneles en: {DASH}')
    print(f'Resumenes en: {RES}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
