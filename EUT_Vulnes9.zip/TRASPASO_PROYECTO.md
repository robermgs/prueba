# EUT Vulnes — Documento de traspaso del proyecto

Este documento resume todo el contexto de un proyecto largo (varias sesiones) para que puedas seguir trabajando en él en una cuenta de Claude distinta. Pégalo al principio de una conversación nueva, **y adjunta también los ficheros del ZIP** (`pipeline_dashboards_EUT_Vulnes.zip`) y los 12 HTML de ejemplo (`dashboard_*.html`, `priorizacion_*.html`, `base.html`) — este documento da el contexto, pero Claude necesita los ficheros reales para poder editarlos.

## Qué es esto

Una herramienta interna de un banco (Santander/SGTO) para generar diariamente ~13 paneles HTML de vulnerabilidades críticas de Qualys, heredada de un compañero (Sergio Rodriguez Rial) que ya no está disponible para mantenerla. El usuario (Roberto/Rober) la usa a diario para su trabajo y necesitaba reconstruir el pipeline que genera esos HTML a partir de dos ficheros CSV de Qualys, sin tener el script original.

## Restricción crítica: Python puro, sin librerías externas

**La política de la empresa NO permite instalar pip packages.** Todo el motor está en Python estándar (`csv`, `re`, `math`, `json`, `datetime`, `collections`) — **NO usar pandas, openpyxl, numpy ni nada que requiera `pip install`**. Esto se descubrió a mitad de proyecto y hubo que reescribir todo el pipeline (que originalmente se hizo con pandas) en Python puro. Si alguna vez se sugiere una librería externa, hay que rechazarla y buscar la alternativa en stdlib.

## Estructura de carpetas (en el PC del usuario, Windows)

```
EUT_Vulnes/
├── csv_diarios/
│   ├── SA.csv                 <- CSV "Critical SANTEC" del día (se sobrescribe)
│   ├── SG.csv                 <- CSV "Critical SGTO" del día (se sobrescribe)
│   ├── Equipos_VIP.csv        <- lista de ~450 máquinas VIP (fuente externa)
│   └── Estado_vulnes_1.csv    <- seguimiento manual de tickets (fuente externa)
├── scripts/                    <- todos los .py y el run_diario.bat
├── historico/                  <- los historico_*.json y snapshots, los gestionan los scripts
├── dashboards/                 <- los 13 HTML "maestros" que se regeneran cada día
└── resumenes/                  <- salidas diarias: resumen ejecutivo, tabla Teams, fixed, etc.
```

Cada día: el usuario sustituye `SA.csv`/`SG.csv` con los nuevos, y ejecuta `run_diario.bat` (opcionalmente con la fecha: `run_diario.bat 2026-09-03`; si no la pasa, coge la fecha del sistema vía PowerShell para evitar problemas de formato regional).

## Los CSV de entrada

Export de Qualys, separador `;` (aunque `core.py` ya detecta automáticamente `,` también, por si acaso), encoding latin-1 la mayoría de veces (también se intenta utf-8-sig/utf-8). Columnas clave: `Host Id, QID, Title, Netbios Name, OS, Activity, Status, Dias_Publicada, Overdue, Es_Nueva, Entidad, Subentidad, DA, Minerva, Estado_SCCM, ...`. Dos ficheros: `SA.csv` (entorno SANTEC) y `SG.csv` (entorno SGTO) — se combinan añadiendo el campo `env`.

## Decisiones de diseño importantes (¡no revertir sin motivo!)

1. **Normalización de máquina**: `norm = Netbios Name.strip().upper()`. Es la clave de agrupación en todo el proyecto.

2. **"Máquinas" de una vulnerabilidad = DEDUPLICADAS por máquina** (no filas en bruto). Esto se confirmó y re-confirmó dos veces con validación cruzada contra la herramienta real de Sergio (capturas de Teams) y contra cálculos manuales del usuario. Hubo un intento fallido de cambiar a "filas en bruto" que se revirtió — **no repetir ese error**.

3. **Pero el usuario TAMBIÉN necesita el dato "en bruto"** para sus cruces manuales en Excel (cuenta filas sin deduplicar). Por eso existe un panel aparte, `dashboard_bruto.html`, específicamente con esa métrica — los dos criterios conviven en la herramienta, cada uno en su sitio.

4. **Máquinas Mac/Linux**: el equipo del usuario NO las atiende, pero NO se excluyen de los datos — se marcan con `en_alcance=False` en `tabla_maquinas()` y no cuentan en las cifras de cabecera (`machines_total`, `vulns_total`, `overdue_total`, `titles_unique`, alineación) del resumen diario, pero siguen presentes en `machines_all` para poder consultarlas filtrando por S.O. en el propio panel.

5. **Campo "estado" (tickets) y "vip"**: NO se pueden derivar de los CSV de Qualys. Vienen de `Estado_vulnes_1.csv` (columna `Estado`, indexado por título exacto de la vulnerabilidad) y `Equipos_VIP.csv` (lista de Netbios) respectivamente. `dashboard_maquina_detalle.html` ya los usa correctamente.

6. **Status=FIXED del CSV NO es fiable** para saber qué se arregló de verdad (Sergio lo confirmó: puede aparecer así simplemente porque la máquina dejó de reportar a Qualys). El criterio correcto es cruzar el CSV de hoy contra un snapshot de ayer y ver qué combinaciones (máquina, QID) desaparecieron. Implementado en `generar_resumen_fixed.py` con `historico/snapshot_vulnes.json`.

7. **Regla SLA**: una vulnerabilidad pasa a "overdue" el día 31 desde su publicación (no el día 30) — aunque en la práctica se usa directamente la columna `Overdue` del CSV, ya calculada por Qualys.

8. **Regla "vivas" para el scoring DORA (exposición)**: **SIN RESOLVER**. El original solo cuenta como "expuestas" las máquinas "vivas", pero no se ha conseguido reproducir el criterio exacto (no es antigüedad de reporte ni `Estado_Operativo`; probó combinaciones de SCCM/DA/Minerva sin éxito). El usuario iba a preguntarle a Sergio por un posible fichero de bajas/inventario de activos. De momento se cuentan todas las máquinas (aproximación), lo que hace que salgan más filas en `priorizacion_*` (427) que en el original (363).

## Los ficheros del proyecto

### `core.py` — motor central, lo usan todos los generadores
Funciones principales: `cargar_datos()`, `tabla_maquinas()`, `resumen_dia()`, `vulns_del_dia()` / `vulns_del_dia_por_titulo()`, `vuln_detail_por_titulo()`, `filas_bruto()`, `alignment_breakdown()`, `puntuar_dora()` (motor de scoring DORA, ver más abajo), `filas_priorizacion()`, `cargar_vip()`, `cargar_estados()`, `categoria_os()`, `rango_dias()`, `bucket_maquinas()`, `nombre_software()` / `categoria_software()` (aproximados), `redactar_titulo()`.

### Scripts generadores (uno por panel), todos en `scripts/`
- `generar_resumen.py` → `dashboard_resumen.html`
- `generar_vulnerabilidades.py` → `dashboard_vulnerabilidades.html` (agrupa por TÍTULO, no QID)
- `generar_maquinas_desalineadas.py` → `dashboard_maquinas_desalineadas.html` (histórico recortado a 60 días)
- `generar_no_overdue.py` → `dashboard_no_overdue.html` (conserva `remediation_by_title`, notas manuales)
- `generar_overdue_json.py` → `dashboard_overdue_json.html` (fichero enorme, se procesa en BINARIO por memoria, recortado a 30 días)
- `generar_vuln_detalle.py` → `dashboard_vuln_detalle.html`
- `generar_maquina_detalle.py` → `dashboard_maquina_detalle.html` (usa VIP/Estado reales)
- `generar_resumen_entidades.py` → `dashboard_resumen_entidades.html` (sin histórico)
- `generar_recurrencia_software.py` → `dashboard_recurrencia_software.html` (aproximado, ver pendientes)
- `generar_priorizacion.py` → los 3 `priorizacion_*.html` (motor DORA)
- `generar_bruto.py` → `dashboard_bruto.html` (NUEVO — detecciones en bruto + variación, con toggle de agrupación por título exacto)
- `generar_resumen_ejecutivo.py` → `resumenes/resumen_ejecutivo_<fecha>.txt` + `evolutivo_teams_<fecha>.txt`
- `generar_tabla_teams.py` → `resumenes/tabla_teams_<fecha>.html` (tabla HTML para copiar/pegar en Teams)
- `generar_resumen_fixed.py` → `resumenes/resumen_maquinas_fixed_<fecha>.csv` + `resumen_vulnes_fixed_<fecha>.csv` (cruce día-a-día)
- `rellenar_historico.py` → utilidad para rellenar histórico hacia atrás con CSV antiguos (patrón de nombre `YYYYMMDD_Critical_SGTO.csv` / `..._SANTEC.csv`)
- `run_diario.bat` → ejecuta todo en orden, abre `base.html` al terminar

### Patrón común de los scripts
Cada uno recibe `SA.csv SG.csv FECHA --template plantilla.html --historico historico_X.json --out salida.html`. La primera vez, si no existe el histórico, lo siembra extrayendo los datos ya embebidos en el HTML de ejemplo original (regex sobre `const NOMBRE = {...};`). Cada día siguiente, actualiza el histórico y regenera el HTML sustituyendo solo los bloques de datos (JS consts), preservando intacto el resto del HTML/CSS/JS.

## Motor de scoring DORA (`puntuar_dora` en core.py)

Reconstruido por ingeniería inversa contra las 363 filas reales de `priorizacion_OPERATIVA.html` — **validado**: banda de riesgo acierta 100%, score cuadra 96.7% (el resto eran inconsistencias ya existentes en el original). 6 factores:
- **Severidad** (max 20): keywords en el título (RCE=10/10, EOL=9, privilege escalation=8.5, etc.), tabla en `SEVERIDAD_KEYWORDS`.
- **Exposición** (max 20): `20 * ln(maquinas) / ln(machines_total)` — fórmula logarítmica confirmada exacta.
- **SLA** (max 20): `20 * min(dias_vida/30, 1)^2` — fórmula cuadrática confirmada exacta.
- **Overdue** (max 15): `15 * min(overdue_pct/100, 1)`.
- **Criticidad/VIP** (max 15): `3 + 15*(vip/maquinas)` si hay algún VIP afectado, si no 0.
- **Tendencia** (max 10): 10 si sube, 6 si estable, 0 si baja.
Score total → banda: ≥75 CRÍTICA (48h), ≥60 ALTA (7 días), ≥40 MEDIA (30 días), si no BAJA (ciclo normal).

## Pendientes / aproximaciones conocidas (decirlo con honestidad si se pregunta)

1. **"Máquinas vivas" en DORA**: sin resolver (ver arriba).
2. **`dashboard_recurrencia_software.html`**: el nombre de "familia de software" no sigue una regla algorítmica limpia en el original (parece tener retoques manuales de Sergio); se aproxima con alias conocidos + heurística de primeras palabras. Salen ~105 productos vs 126 originales — cercano pero no exacto.
3. **Gráfico Chrome/Edge** en `dashboard_vulnerabilidades.html`: aproximado (suma de `machines_count` de títulos que mencionan el navegador, sin deduplicar entre títulos) — se acerca al rango histórico real pero no es fórmula exacta confirmada.
4. **Categorización de software para `priorizacion_PUBLICA.html`** (anonimizado por categoría: Navegador, Sistema operativo, etc.) usa la misma heurística aproximada.

## Historial de versiones

- **v1.0**: estado estable con todo lo descrito arriba. Fecha de referencia: primeros días de septiembre de 2026.
- (A partir de aquí, numerar v1.1, v1.2... cada vez que se entregue un cambio relevante, y sería buena práctica mantener un `CHANGELOG.txt` en el ZIP.)

## Cómo entregar los cambios

El usuario prefiere recibir un ZIP único descargable (`pipeline_dashboards_EUT_Vulnes.zip`) con todos los `.py` y el `.bat`, que se regenera/actualiza en el mismo enlace cada vez que hay cambios, en vez de artifacts sueltos. Los HTML grandes (dashboards regenerados) se han ido entregando sueltos para que el usuario los revise, pero el ZIP es solo para los scripts.

## Estilo de trabajo con este usuario

- Es del área de seguridad/vulnerabilidades de un banco, trabaja en Windows, sin permisos para instalar librerías Python.
- Prefiere respuestas directas y validación con datos reales (siempre que sea posible, probar contra sus CSV antes de entregar).
- Cuando algo es una aproximación o no se ha podido validar al 100%, decírselo explícitamente en vez de asumir que está bien.
- Varias veces ha corregido información (criterios de conteo, campo Status, etc.) tras consultar con su excompañero Sergio — cuando dé una corrección así, tomarla como autoritativa y no resistirse aunque contradiga un trabajo anterior ya validado.
