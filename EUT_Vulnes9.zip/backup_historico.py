r"""
Copia de seguridad de lo IMPORTANTE antes de tocar nada: la carpeta
historico\ (todos los .json/snapshots) y tus dos ficheros manuales
(Estado_vulnes_1.csv, Equipos_VIP.csv). Se guarda todo en un único ZIP
por ejecución dentro de historico\backups\.

No hace falta respaldar los HTML de dashboards\: se pueden regenerar en
cualquier momento a partir del histórico + los CSV del día. Lo único que
de verdad se perdería si algo sale mal es lo que respalda este script.

Mantiene solo los últimos --max-backups (por defecto 14) — los más
antiguos se van borrando solos para no acumular sin límite.

Uso:
    python3 backup_historico.py ..\historico ..\csv_diarios 2026-09-03
"""
import argparse
import glob
import os
import sys
import zipfile
from datetime import datetime


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('carpeta_historico')
    ap.add_argument('carpeta_csv')
    ap.add_argument('fecha')
    ap.add_argument('--max-backups', type=int, default=14)
    args = ap.parse_args()

    carpeta_backups = os.path.join(args.carpeta_historico, 'backups')
    os.makedirs(carpeta_backups, exist_ok=True)

    sello = datetime.now().strftime('%H%M%S')
    zip_path = os.path.join(carpeta_backups, f'backup_{args.fecha}_{sello}.zip')

    print(f'Haciendo copia de seguridad en {zip_path}...')
    n_ficheros = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in glob.glob(os.path.join(args.carpeta_historico, '*.json')):
            z.write(path, arcname=os.path.join('historico', os.path.basename(path)))
            n_ficheros += 1
        for nombre in ('Estado_vulnes_1.csv', 'Equipos_VIP.csv'):
            path = os.path.join(args.carpeta_csv, nombre)
            if os.path.exists(path):
                z.write(path, arcname=os.path.join('csv_diarios', nombre))
                n_ficheros += 1

    print(f'Copia hecha: {n_ficheros} fichero(s).')

    # Rotación: nos quedamos solo con los --max-backups más recientes
    backups = sorted(glob.glob(os.path.join(carpeta_backups, 'backup_*.zip')))
    if len(backups) > args.max_backups:
        for viejo in backups[:-args.max_backups]:
            os.remove(viejo)
        print(f'Rotación: borrados {len(backups) - args.max_backups} backup(s) antiguo(s), '
              f'quedan los últimos {args.max_backups}.')

    return 0


if __name__ == '__main__':
    sys.exit(main())
