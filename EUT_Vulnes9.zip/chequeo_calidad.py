r"""
Chequeo de calidad de datos — se ejecuta ANTES de generar los paneles.
Compara unas pocas cifras básicas de los CSV de hoy contra las de ayer
(guardadas en un pequeño fichero de referencia) y avisa bien fuerte si
hay un cambio anómalo (como la caída del -33% que se detectó a mano),
en vez de que te enteres mirando los paneles ya generados.

Umbral por defecto: ±15% en cualquiera de las cifras básicas dispara un
aviso (no detiene la ejecución). Si el CSV está prácticamente vacío
(menos de 1000 filas en total), se considera un fallo grave y SÍ detiene
la ejecución (código de salida 1), porque seguir generando paneles con
un CSV roto no tiene sentido.

Uso:
    python3 chequeo_calidad.py SA.csv SG.csv 2026-09-03 --baseline ..\historico\baseline_calidad.json
"""
import argparse
import json
import sys

from core import cargar_datos

MINIMO_FILAS_ABSOLUTO = 1000
UMBRAL_AVISO_PCT = 15


def metricas(filas):
    sa = sum(1 for r in filas if r['env'] == 'SANTEC')
    sg = sum(1 for r in filas if r['env'] == 'SGTO')
    return {
        'filas_total': len(filas), 'filas_sa': sa, 'filas_sg': sg,
        'maquinas_unicas': len(set(r['norm'] for r in filas)),
        'qids_unicos': len(set(r['QID'] for r in filas)),
    }


def cargar_baseline(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def pct_cambio(hoy, ayer):
    if ayer == 0:
        return 0.0 if hoy == 0 else 100.0
    return round((hoy - ayer) / ayer * 100, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--baseline', default='baseline_calidad.json')
    ap.add_argument('--umbral', type=float, default=UMBRAL_AVISO_PCT)
    args = ap.parse_args()

    print('Cargando CSV para el chequeo de calidad...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    m_hoy = metricas(filas)

    print(f"Filas totales hoy: {m_hoy['filas_total']:,} (SANTEC {m_hoy['filas_sa']:,} / SGTO {m_hoy['filas_sg']:,})".replace(',', '.'))
    print(f"Máquinas únicas: {m_hoy['maquinas_unicas']:,} | QIDs únicos: {m_hoy['qids_unicos']:,}".replace(',', '.'))

    if m_hoy['filas_total'] < MINIMO_FILAS_ABSOLUTO:
        print()
        print('=' * 60)
        print(f"*** FALLO CRÍTICO: el CSV combinado solo tiene {m_hoy['filas_total']} filas")
        print(f"*** (mínimo esperado: {MINIMO_FILAS_ABSOLUTO}). Algo va muy mal con estos ficheros.")
        print("*** Se detiene la ejecución. Revisa los CSV antes de continuar.")
        print('=' * 60)
        return 1

    baseline = cargar_baseline(args.baseline)
    if baseline is None:
        print('(No hay un chequeo de un día anterior con el que comparar — normal la primera vez.)')
    else:
        avisos = []
        for clave, etiqueta in [
            ('filas_total', 'Filas totales'), ('filas_sa', 'Filas SANTEC'), ('filas_sg', 'Filas SGTO'),
            ('maquinas_unicas', 'Máquinas únicas'), ('qids_unicos', 'QIDs únicos'),
        ]:
            cambio = pct_cambio(m_hoy[clave], baseline['metricas'][clave])
            if abs(cambio) >= args.umbral:
                avisos.append((etiqueta, baseline['metricas'][clave], m_hoy[clave], cambio))

        if avisos:
            print()
            print('=' * 60)
            print(f"*** AVISO: cambios de más del {args.umbral:.0f}% respecto a {baseline['fecha']}:")
            for etiqueta, antes, ahora, cambio in avisos:
                signo = '+' if cambio > 0 else ''
                print(f"***   {etiqueta}: {antes:,} -> {ahora:,}  ({signo}{cambio}%)".replace(',', '.'))
            print("*** Puede ser normal (ej. una tanda grande de despliegues) o un problema")
            print("*** con el export de Qualys. Conviene confirmarlo antes de fiarte del todo")
            print("*** de los paneles/evolutivo de hoy.")
            print('=' * 60)
        else:
            print(f"Todo dentro de rango normal (< {args.umbral:.0f}% de cambio) respecto a {baseline['fecha']}.")

    with open(args.baseline, 'w', encoding='utf-8') as f:
        json.dump({'fecha': args.fecha, 'metricas': m_hoy}, f, ensure_ascii=False)

    return 0


if __name__ == '__main__':
    sys.exit(main())
