r"""
Compara dos fechas cualquiera del histórico de dashboard_resumen.html
(no tienen que ser consecutivas) — por ejemplo, "¿cómo estábamos hace un
mes?".

Uso:
    python3 comparar_fechas.py ..\historico\historico_resumen.json 2026-08-01 2026-09-02 \
        --out ..\resumenes\comparativa_2026-08-01_vs_2026-09-02.txt
"""
import argparse
import json
import sys


def num(n):
    return f'{n:,}'.replace(',', '.')


def flecha_txt(delta):
    if delta > 0:
        return f'subió +{num(delta)}'
    if delta < 0:
        return f'bajó {num(delta)}'
    return 'se mantuvo igual'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('historico_resumen')
    ap.add_argument('fecha1', help='Fecha más antigua (YYYY-MM-DD)')
    ap.add_argument('fecha2', help='Fecha más reciente (YYYY-MM-DD)')
    ap.add_argument('--out', default='comparativa.txt')
    args = ap.parse_args()

    with open(args.historico_resumen, 'r', encoding='utf-8') as f:
        hist = json.load(f)

    disponibles = hist['fechas']
    for fecha in (args.fecha1, args.fecha2):
        if fecha not in disponibles:
            print(f'ERROR: no hay histórico para la fecha {fecha}.')
            print('Fechas disponibles:', ', '.join(disponibles))
            return 1

    s1 = hist['summary'][args.fecha1]
    s2 = hist['summary'][args.fecha2]

    desalin1 = round(100 * s1['alignment_desalin_global'] / s1['alignment_total_global'], 1) \
        if s1['alignment_total_global'] else 0
    desalin2 = round(100 * s2['alignment_desalin_global'] / s2['alignment_total_global'], 1) \
        if s2['alignment_total_global'] else 0

    lineas = [
        f'COMPARATIVA · {args.fecha1} vs {args.fecha2}',
        '=' * 60,
        '',
    ]

    metricas = [
        ('Máquinas vulnerables', s1['machines_total'], s2['machines_total']),
        ('Vulnerabilidades totales', s1['vulns_total'], s2['vulns_total']),
        ('En overdue', s1['overdue_total'], s2['overdue_total']),
        ('Títulos únicos', s1['titles_unique'], s2['titles_unique']),
    ]
    for nombre, v1, v2 in metricas:
        delta = v2 - v1
        pct = round(100 * delta / v1, 1) if v1 else None
        pct_txt = f' ({pct:+.1f}%)' if pct is not None else ''
        lineas.append(f'{nombre}:')
        lineas.append(f'  {args.fecha1}: {num(v1)}   ->   {args.fecha2}: {num(v2)}   '
                       f'({flecha_txt(delta)}{pct_txt})')
        lineas.append('')

    lineas.append('% Desalineadas:')
    lineas.append(f'  {args.fecha1}: {desalin1}%   ->   {args.fecha2}: {desalin2}%   '
                   f'({desalin2 - desalin1:+.1f} puntos)')

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
