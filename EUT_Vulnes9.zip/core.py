"""
Motor de cálculo para los dashboards de vulnerabilidades (EUT Vulnes).

Reescrito en PYTHON PURO (solo librería estándar: csv, re, math, json,
datetime, collections) — sin pandas ni openpyxl, porque la política de la
empresa no permite instalar librerías externas. Los ficheros de entrada
deben ser CSV (mismo formato que exporta Qualys: separador ';', encoding
latin-1).

Uso:
    from core import cargar_datos, tabla_maquinas, resumen_dia
    filas = cargar_datos('SA.csv', 'SG.csv')
    machine_table = tabla_maquinas(filas, fecha_informe='2026-08-27')
"""
import csv
import re
import math
import json
from datetime import datetime, timedelta
from collections import defaultdict, Counter

csv.field_size_limit(2**31 - 1)


# ---------------------------------------------------------------------------
# Carga de datos
# ---------------------------------------------------------------------------

def _leer_csv(path: str) -> list:
    """Lee un CSV de Qualys como lista de dicts. Detecta automáticamente si
    el separador es ';' o ',' (algunos exports/VDI usan uno u otro) y usa la
    primera codificación que consiga leer el fichero sin errores."""
    for encoding in ('latin-1', 'utf-8-sig', 'utf-8'):
        try:
            with open(path, 'r', encoding=encoding, newline='') as f:
                primera_linea = f.readline()
            break
        except UnicodeDecodeError:
            continue
    else:
        encoding = 'latin-1'
        with open(path, 'r', encoding=encoding, newline='') as f:
            primera_linea = f.readline()

    delimitador = ';' if primera_linea.count(';') >= primera_linea.count(',') else ','

    filas = []
    with open(path, 'r', encoding=encoding, newline='') as f:
        reader = csv.DictReader(f, delimiter=delimitador)
        if 'QID' not in (reader.fieldnames or []):
            raise ValueError(
                f"No se ha encontrado la columna 'QID' en {path} usando el separador "
                f"'{delimitador}'. Columnas detectadas: {reader.fieldnames}"
            )
        for row in reader:
            filas.append(row)
    return filas


def _fuera_de_alcance(os_texto: str) -> bool:
    """El equipo no atiende máquinas Mac ni Linux. NO se excluyen de los
    datos (siguen pudiéndose consultar filtrando por S.O.), pero se marcan
    como fuera del alcance principal para que no cuenten en los totales
    "de cabecera" del resumen diario y el evolutivo de Teams."""
    t = (os_texto or '').lower()
    if 'mac' in t or 'os x' in t:
        return True
    if any(k in t for k in ('linux', 'ubuntu', 'red hat', 'centos', 'debian', 'suse', 'canonical')):
        return True
    return False


def cargar_datos(sa_path: str, sg_path: str) -> list:
    """Carga y combina los dos CSV de Qualys (SA=SANTEC, SG=SGTO) en una
    única lista de dicts, con 'env' y 'norm' (máquina normalizada) añadidos.
    Las máquinas Mac/Linux NO se excluyen (se siguen pudiendo consultar),
    pero se marcan como fuera del alcance principal del equipo — ver
    tabla_maquinas() y 'en_alcance'."""
    sa = _leer_csv(sa_path)
    for r in sa:
        r['env'] = 'SANTEC'
    sg = _leer_csv(sg_path)
    for r in sg:
        r['env'] = 'SGTO'
    filas = sa + sg
    for r in filas:
        r['norm'] = (r.get('Netbios Name') or '').strip().upper()
        if not r.get('Entidad'):
            r['Entidad'] = 'NO'
        if not r.get('Subentidad'):
            r['Subentidad'] = 'NO'
    return filas


def _overdue_bool(r: dict) -> bool:
    return (r.get('Overdue') or 'FALSO').strip().upper() == 'VERDADERO'


def _dias_publicada(r: dict):
    try:
        return int(str(r.get('Dias_Publicada')).strip())
    except (ValueError, TypeError):
        return None


UMBRAL_OVERDUE_DIA = 31


def fecha_entrada_overdue(fecha_hoy_str: str, dias_publicada) -> str:
    """Fecha exacta en la que una vulnerabilidad entró en overdue, calculada
    hacia atrás desde hoy usando Dias_Publicada (el CSV ya trae ese campo,
    así que no hace falta histórico día a día para saberlo).
    Devuelve None si dias_publicada es None o todavía no está en overdue."""
    if dias_publicada is None or dias_publicada < UMBRAL_OVERDUE_DIA:
        return None
    hoy = datetime.strptime(fecha_hoy_str, '%Y-%m-%d')
    entrada = hoy - timedelta(days=dias_publicada - UMBRAL_OVERDUE_DIA)
    return entrada.strftime('%Y-%m-%d')


# ---------------------------------------------------------------------------
# Clasificación SCCM / DA / Minerva
# ---------------------------------------------------------------------------

def _cat(v) -> str:
    l = str(v or '').lower()
    if l == '' or l == 'nan' or 'sin datos' in l or 'sin columna' in l:
        return 'sd'
    for k in ('en sccm', 'productiv', 'operativ'):
        if k in l:
            return 'ok'
    return 'ko'


def _cruce(c_sccm: str, c_da: str, c_min: str) -> str:
    vals = {c_sccm, c_da, c_min}
    if vals == {'ok'}:
        return 'Alineada'
    if vals == {'ko'}:
        return 'Desalineada'
    if vals == {'sd'}:
        return 'Sin datos'
    return 'Parcial'


def rango_dias(dias) -> str:
    if dias is None:
        return 'gt10'
    if dias <= 0:
        return 'hoy'
    if dias <= 2:
        return 'r12'
    if dias <= 10:
        return 'r310'
    return 'gt10'


# ---------------------------------------------------------------------------
# Tabla de máquinas (una fila por máquina)
# ---------------------------------------------------------------------------

def categoria_os(os_texto: str) -> str:
    """La interfaz espera 'Windows' / 'Mac' / 'Otro', no el texto completo del CSV."""
    t = (os_texto or '').lower()
    if 'windows' in t:
        return 'Windows'
    if 'mac' in t or 'os x' in t or 'macos' in t:
        return 'Mac'
    return 'Otro'


def tabla_maquinas(filas: list, fecha_informe: str = None) -> list:
    """Construye la tabla de máquinas únicas (una entrada por 'norm'):
    env, ent, sub, count (nº de vulns únicas), os, cruce, dias_sin_reportar."""
    por_maquina = defaultdict(list)
    for r in filas:
        por_maquina[r['norm']].append(r)

    hoy = None
    if fecha_informe:
        hoy = datetime.strptime(fecha_informe, '%Y-%m-%d')

    resultado = []
    for norm, rs in por_maquina.items():
        first = rs[0]
        c_sccm = _cat(first.get('Estado_SCCM'))
        c_da = _cat(first.get('DA'))
        c_min = _cat(first.get('Minerva'))
        cruce = _cruce(c_sccm, c_da, c_min)

        qids = set(r['QID'] for r in rs)
        activity_vals = [r.get('Activity') for r in rs if r.get('Activity')]
        activity = max(activity_vals) if activity_vals else None

        dias_sin_reportar = None
        if hoy is not None and activity:
            try:
                act_date = datetime.strptime(activity[:10], '%Y-%m-%d')
                dias_sin_reportar = (hoy - act_date).days
            except ValueError:
                dias_sin_reportar = None

        resultado.append({
            'machine': norm, 'env': first['env'], 'ent': first.get('Entidad', 'NO'),
            'sub': first.get('Subentidad', 'NO'), 'os': categoria_os(first.get('OS', '')),
            'en_alcance': not _fuera_de_alcance(first.get('OS', '')),
            'c_sccm': c_sccm, 'c_da': c_da, 'c_min': c_min, 'cruce': cruce,
            'activity': activity, 'count': len(qids), 'dias_sin_reportar': dias_sin_reportar,
            'asset_id': first.get('Asset Id', ''),
        })
    return resultado


def machines_breakdown(machine_table: list) -> list:
    contador = Counter((m['env'], m['ent'], m['sub']) for m in machine_table)
    return [{'env': e, 'ent': ent, 'sub': s, 'count': c}
            for (e, ent, s), c in contador.items()]


def alignment_breakdown(machine_table: list) -> tuple:
    """Devuelve (breakdown por env/ent/sub, total_global, desalin_global).
    'desalineada' = cualquier máquina cuyo cruce no sea 'Alineada'."""
    grupos = defaultdict(lambda: {'total': 0, 'desalineada': 0})
    total_global = 0
    desalin_global = 0
    for m in machine_table:
        key = (m['env'], m['ent'], m['sub'])
        grupos[key]['total'] += 1
        total_global += 1
        if m['cruce'] != 'Alineada':
            grupos[key]['desalineada'] += 1
            desalin_global += 1
    salida = [{'env': e, 'ent': ent, 'sub': s, 'total': v['total'], 'desalineada': v['desalineada']}
               for (e, ent, s), v in grupos.items()]
    return salida, total_global, desalin_global


# ---------------------------------------------------------------------------
# Vulnerabilidades del día
# ---------------------------------------------------------------------------

def vulns_del_dia(filas: list, titles_previos: dict = None) -> list:
    """Agrupa por QID: una entrada por vulnerabilidad, con desglose por
    env/ent/sub y datos de overdue/nuevo/delta. 'machines' cuenta MÁQUINAS
    ÚNICAS (una vulne por versión y equipo, aunque haya 2 detecciones el
    mismo día) — confirmado por Sergio."""
    por_qid = defaultdict(list)
    for r in filas:
        por_qid[(r['QID'], r['Title'])].append(r)

    out = []
    for (qid, title), rs in por_qid.items():
        vistas = {}
        for r in rs:
            vistas.setdefault(r['norm'], r)
        rs_u = list(vistas.values())
        machines = len(rs_u)
        overdue_bool = any(_overdue_bool(r) for r in rs_u)

        bd_grupos = defaultdict(lambda: {'count': 0, 'overdue': 0})
        for r in rs_u:
            key = (r['env'], r['Entidad'], r['Subentidad'])
            bd_grupos[key]['count'] += 1
            if _overdue_bool(r):
                bd_grupos[key]['overdue'] += 1
        breakdown = [{'env': e, 'ent': ent, 'sub': s, 'count': v['count'], 'overdue': v['overdue']}
                     for (e, ent, s), v in bd_grupos.items()]

        nuevo = titles_previos is not None and qid not in titles_previos
        delta = None
        if titles_previos is not None and qid in titles_previos:
            delta = machines - titles_previos[qid]

        out.append({
            'vuln_key': f"('{qid}', '{title}')", 'qid': qid, 'title': title,
            'machines': machines, 'overdue': overdue_bool, 'estado': 'Sin estado',
            'nuevo': nuevo, 'breakdown': breakdown, 'dias_vida': None, 'delta': delta,
        })
    out.sort(key=lambda v: v['machines'], reverse=True)
    return out


def vulns_del_dia_por_titulo(filas: list, titles_previos: dict = None) -> list:
    """Igual que vulns_del_dia, pero agrupando por TÍTULO (no por QID),
    tal como espera dashboard_vulnerabilidades.html."""
    por_titulo = defaultdict(list)
    for r in filas:
        por_titulo[r['Title']].append(r)

    out = []
    for title, rs in por_titulo.items():
        vistas = {}
        for r in rs:
            vistas.setdefault(r['norm'], r)
        rs_u = list(vistas.values())
        machines = len(rs_u)
        overdue_bool = any(_overdue_bool(r) for r in rs_u)
        qid = rs[0]['QID']

        bd_grupos = defaultdict(lambda: {'count': 0, 'overdue': 0})
        for r in rs_u:
            key = (r['env'], r['Entidad'], r['Subentidad'])
            bd_grupos[key]['count'] += 1
            if _overdue_bool(r):
                bd_grupos[key]['overdue'] += 1
        breakdown = [{'env': e, 'ent': ent, 'sub': s, 'count': v['count'], 'overdue': v['overdue']}
                     for (e, ent, s), v in bd_grupos.items()]

        nuevo = titles_previos is not None and title not in titles_previos
        delta = None
        if titles_previos is not None and title in titles_previos:
            delta = machines - titles_previos[title]

        out.append({
            'vuln_key': f"('{qid}', '{title}')", 'qid': qid, 'title': title,
            'machines': machines, 'overdue': overdue_bool, 'estado': 'Sin estado',
            'nuevo': nuevo, 'breakdown': breakdown, 'dias_vida': None, 'delta': delta,
        })
    out.sort(key=lambda v: v['machines'], reverse=True)
    return out


def top_vulns(vulns_dia: list, n: int = 10) -> list:
    return [{'qid': v['qid'], 'title': v['title'], 'machines': v['machines'], 'estado': v['estado']}
            for v in vulns_dia[:n]]


def combos_unicos(machine_table: list) -> list:
    combos = sorted(set((m['env'], m['ent'], m['sub']) for m in machine_table))
    return [{'env': e, 'ent': ent, 'sub': s} for e, ent, s in combos]


def filas_bruto(filas: list) -> list:
    """Detecciones EN BRUTO (sin deduplicar por máquina) por vulnerabilidad,
    desglosadas por entorno. Es la métrica que usa el cruce manual en Excel
    (cuenta filas, no máquinas únicas) — complementaria a vulns_del_dia."""
    por_qid = defaultdict(list)
    for r in filas:
        por_qid[(r['QID'], r['Title'])].append(r)

    salida = []
    for (qid, title), rs in por_qid.items():
        sgto = sum(1 for r in rs if r['env'] == 'SGTO')
        santec = sum(1 for r in rs if r['env'] == 'SANTEC')
        salida.append({'qid': qid, 'titulo': title, 'sgto': sgto, 'santec': santec, 'total': sgto + santec})
    salida.sort(key=lambda r: -r['total'])
    return salida


def resumen_dia(filas: list, machine_table: list, fecha: str,
                titles_dia_anterior: set = None, vulns_dia: list = None) -> dict:
    """Calcula el objeto SUMMARY[fecha]. Las cifras de cabecera (machines_total,
    vulns_total, overdue_total, titles_unique, alignment_*, top_machines) se
    calculan SOLO con máquinas 'en_alcance' (no Mac/Linux, que el equipo no
    atiende) — pero 'machines_all' conserva TODAS las máquinas, para poder
    consultar las Mac/Linux filtrando por S.O. en el propio panel."""
    machine_table_alcance = [m for m in machine_table if m.get('en_alcance', True)]
    maquinas_alcance = {m['machine'] for m in machine_table_alcance}
    filas_alcance = [r for r in filas if r['norm'] in maquinas_alcance]

    vistas = {}
    for r in filas_alcance:
        vistas.setdefault((r['norm'], r['QID']), r)
    vulns_unicas = list(vistas.values())

    machines_total = len(machine_table_alcance)
    vulns_total = len(vulns_unicas)
    overdue_total = sum(1 for r in vulns_unicas if _overdue_bool(r))
    titles_unique = len(set(r['QID'] for r in filas_alcance))

    titles_hoy = set(r['QID'] for r in filas_alcance)
    nuevos = titles_hoy - titles_dia_anterior if titles_dia_anterior is not None else set()
    new_titles = []
    for qid in nuevos:
        rs = [r for r in filas_alcance if r['QID'] == qid]
        new_titles.append({
            'qid': qid, 'title': rs[0]['Title'],
            'machines': len(set(r['norm'] for r in rs)), 'estado': 'Sin estado',
        })

    top_machines = sorted(machine_table_alcance, key=lambda m: -m['count'])[:25]
    ab, ab_total, ab_desalin = alignment_breakdown(machine_table_alcance)

    return {
        'machines_total': machines_total, 'machines_breakdown': machines_breakdown(machine_table_alcance),
        'vulns_total': vulns_total, 'overdue_total': overdue_total, 'titles_unique': titles_unique,
        'vulns_new': len(new_titles), 'new_titles': new_titles,
        'top_vulns': top_vulns(vulns_dia) if vulns_dia is not None else [],
        'top_machines': top_machines, 'machines_all': machine_table,
        'alignment_breakdown': ab, 'alignment_total_global': ab_total, 'alignment_desalin_global': ab_desalin,
    }


# ---------------------------------------------------------------------------
# Detalle de vulnerabilidad por título (VULN_DETAIL)
# ---------------------------------------------------------------------------

def vuln_detail_por_titulo(filas: list, machine_table: list, fecha: str) -> dict:
    mt_idx = {m['machine']: m for m in machine_table}
    por_titulo = defaultdict(list)
    for r in filas:
        por_titulo[r['Title']].append(r)

    out = {}
    for title, rs in por_titulo.items():
        vistas = {}
        for r in rs:
            vistas.setdefault(r['norm'], r)
        rs_u = list(vistas.values())
        qid = rs[0]['QID']

        machines_list = []
        for r in rs_u:
            m = mt_idx.get(r['norm'])
            machines_list.append({
                'machine': r['norm'], 'env': r['env'], 'ent': r['Entidad'], 'sub': r['Subentidad'],
                'overdue': _overdue_bool(r), 'activity': r.get('Activity'),
                'cruce': m['cruce'] if m else 'Sin datos',
                'dias_sin_reportar': m['dias_sin_reportar'] if m else None,
            })

        dias_pub = [d for d in (_dias_publicada(r) for r in rs) if d is not None]

        detecciones_por_env = defaultdict(int)
        for r in rs:
            detecciones_por_env[r['env']] += 1

        out[title] = {
            'title': title, 'qid': qid, 'estado': 'Sin estado',
            'machines_count': len(rs_u),
            'overdue_count': sum(1 for r in rs_u if _overdue_bool(r)),
            'dias_vida': max(dias_pub) if dias_pub else None,
            'history': [],
            'machines_list': machines_list,
            'detecciones_brutas': len(rs),
            'detecciones_por_env': dict(detecciones_por_env),
            'variacion_brutas': None,  # se rellena en el script generador (necesita el día anterior)
        }
    return out


def conteo_navegador(vuln_detail: dict, patron: str) -> int:
    """Aproximación del histórico Chrome/Edge: suma las 'machines_count' de
    todos los títulos que casan con el patrón, sin deduplicar entre títulos."""
    patron = patron.lower()
    total = 0
    for title, det in vuln_detail.items():
        if patron in title.lower():
            total += det['machines_count']
    return total


# ---------------------------------------------------------------------------
# Ficheros externos: VIP y estado manual
# ---------------------------------------------------------------------------

def ultima_fecha_estado(historial, estado):
    """Última fecha DD/MM/YYYY encontrada en Historial o Estado (algunas
    filas antiguas registran la fecha en el campo Estado, sin corchetes)."""
    import re
    from datetime import datetime
    patron = re.compile(r'(\d{2})/(\d{2})/(\d{4})')
    fechas = []
    for texto in (historial, estado):
        for m in patron.finditer(texto or ''):
            dd, mm, yyyy = m.groups()
            try:
                fechas.append(datetime(int(yyyy), int(mm), int(dd)))
            except ValueError:
                continue
    return max(fechas) if fechas else None


def cargar_estados(path: str) -> dict:
    """Carga Estado_vulnes_1.csv -> {title: estado} (seguimiento manual real)."""
    salida = {}
    with open(path, 'r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        for row in reader:
            salida[row['Title']] = row.get('Estado') or 'Sin estado'
    return salida


def cargar_vip(path: str) -> set:
    """Carga Equipos_VIP.csv y devuelve el set de nombres de máquina normalizados."""
    vip = set()
    with open(path, 'r', encoding='latin-1', newline='') as f:
        reader = csv.DictReader(f)
        col = 'Netbios Name' if reader.fieldnames and 'Netbios Name' in reader.fieldnames else (reader.fieldnames[1] if reader.fieldnames else None)
        for row in reader:
            if col:
                vip.add((row.get(col) or '').strip().upper())
    return vip


# ---------------------------------------------------------------------------
# Resumen y detalle por entidad
# ---------------------------------------------------------------------------

def overdue_por_entidad(filas: list) -> dict:
    """dict {entidad: {'vulns_total': N, 'overdue': N}} — deduplicado por (máquina, QID)."""
    vistas = {}
    for r in filas:
        vistas.setdefault((r['norm'], r['QID']), r)
    por_ent = defaultdict(lambda: {'vulns_total': 0, 'overdue': 0})
    for r in vistas.values():
        ent = r.get('Entidad', 'NO')
        por_ent[ent]['vulns_total'] += 1
        if _overdue_bool(r):
            por_ent[ent]['overdue'] += 1
    return dict(por_ent)


def resumen_por_entidad(machine_table: list) -> list:
    grupos = defaultdict(list)
    for m in machine_table:
        grupos[m['ent']].append(m)

    filas = []
    for ent, ms in grupos.items():
        total = len(ms)
        alin = sum(1 for m in ms if m['cruce'] == 'Alineada')
        row = {
            'ent': ent, 'total': total, 'alineadas': alin,
            'desalineadas': sum(1 for m in ms if m['cruce'] == 'Desalineada'),
            'parcial': sum(1 for m in ms if m['cruce'] == 'Parcial'),
            'sin_datos': sum(1 for m in ms if m['cruce'] == 'Sin datos'),
            'pct_alin': round(100 * alin / total, 1) if total else 0,
        }
        for col, short in [('c_sccm', 'sccm'), ('c_da', 'da'), ('c_min', 'minerva')]:
            for cat in ('ok', 'ko', 'sd'):
                row[f'{short}_{cat}'] = sum(1 for m in ms if m[col] == cat)
        for rg in ('hoy', 'r12', 'r310', 'gt10'):
            row[rg] = sum(1 for m in ms if m.get('range') == rg)
        filas.append(row)
    filas.sort(key=lambda r: -r['total'])
    return filas


def detalle_por_entidad(filas: list) -> dict:
    """Distribución de valores crudos de SCCM/DA/Minerva por entidad (una fila por máquina)."""
    vistas = {}
    for r in filas:
        vistas.setdefault(r['norm'], r)
    por_ent = defaultdict(list)
    for r in vistas.values():
        por_ent[r.get('Entidad', 'NO')].append(r)

    out = {}
    for ent, rs in por_ent.items():
        out[ent] = {
            'sccm': [[k, v] for k, v in Counter(r.get('Estado_SCCM') for r in rs).most_common()],
            'da': [[k, v] for k, v in Counter(r.get('DA') for r in rs).most_common()],
            'minerva': [[k, v] for k, v in Counter(r.get('Minerva') for r in rs).most_common()],
        }
    return out


# ---------------------------------------------------------------------------
# Panel no-overdue / overdue
# ---------------------------------------------------------------------------

def filas_por_grupo_titulo(filas: list, fecha: str, solo_no_overdue: bool,
                            counts_previos: dict = None) -> list:
    """Agrega por (env, ent, sub, title): nº de máquinas únicas y días de
    publicación máximos."""
    if solo_no_overdue:
        filas = [r for r in filas if not _overdue_bool(r)]

    vistas = {}
    for r in filas:
        vistas.setdefault((r['norm'], r['Title'], r['Entidad'], r['Subentidad'], r['env']), r)

    grupos = defaultdict(list)
    for r in vistas.values():
        grupos[(r['env'], r['Entidad'], r['Subentidad'], r['Title'])].append(r)

    salida = []
    for (env, ent, sub, title), rs in grupos.items():
        count = len(rs)
        dias_pub = [d for d in (_dias_publicada(r) for r in rs) if d is not None]
        max_days_pub = max(dias_pub) if dias_pub else 0
        fila = {'fecha': fecha, 'env': env, 'ent': ent, 'sub': sub, 'title': title,
                'count': count, 'max_days_pub': max_days_pub}
        if solo_no_overdue:
            key = (env, ent, sub, title)
            prev = counts_previos.get(key) if counts_previos else None
            fila['new_count'] = count if prev is None else max(0, count - prev)
        salida.append(fila)
    return salida


def filas_overdue(filas: list, fecha: str) -> list:
    """Una fila por (máquina, título) que está actualmente overdue."""
    vistas = {}
    for r in filas:
        if _overdue_bool(r):
            vistas.setdefault((r['norm'], r['Title']), r)
    salida = []
    for r in vistas.values():
        salida.append({
            'fecha': fecha, 'entorno': r['env'], 'entidad': r['Entidad'], 'subentidad': r['Subentidad'],
            'netbios': r['norm'], 'ip': '', 'title': r['Title'], 'severity': '', 'overdue': True,
        })
    return salida


# ---------------------------------------------------------------------------
# Categorización de software (aproximada) y priorización DORA
# ---------------------------------------------------------------------------

_SOFTWARE_ALIASES = [
    ('chrome', 'Google Chrome'), ('edge based on chromium', 'Microsoft Edge'),
    ('firefox', 'Mozilla Firefox'), ('safari', 'Apple Safari'),
    ('windows', 'Microsoft Windows'), ('office', 'Microsoft Office'),
    ('.net framework', '.NET Framework'), ('visual studio code', 'Visual Studio Code'),
    ('visual studio', 'Microsoft Visual Studio'), ('node.js', 'Node.js'),
    ('python', 'Python'), ('java', 'Java'), ('git', 'Git'),
    ('docker desktop', 'Docker Desktop'), ('apache', 'Apache'), ('mysql', 'MySQL'),
    ('dell client', 'Dell Client'), ('bios', 'Dell Client'),
]


def nombre_software(title: str) -> str:
    t = title.lower()
    if t.startswith('eol/obsolete software:'):
        resto = title.split(':', 1)[1].strip().split()
        return 'EOL/Obsolete Software: ' + (resto[0] if resto else '')
    for kw, nombre in _SOFTWARE_ALIASES:
        if kw in t:
            return nombre
    palabras = title.split()
    salida = []
    for p in palabras[:3]:
        if re.match(r'^\d', p) or p.lower() in ('prior', 'multiple', 'vulnerabilities', 'update', 'security', 'for'):
            break
        salida.append(p)
    return ' '.join(salida) if salida else (palabras[0] if palabras else title)


CATEGORIAS_SOFTWARE = [
    (['chrome', 'edge based on chromium', 'firefox', 'safari'], 'Navegador'),
    (['windows', 'operating system', 'linux', 'macos', 'red hat', 'ubuntu'], 'Sistema operativo'),
    (['python', 'java', 'node.js', '.net', 'php', 'openssl'], 'Entorno de ejecución'),
    (['office', 'outlook', 'teams', 'sharepoint'], 'Herramienta de trabajo'),
    (['apache', 'server', 'tomcat', 'nginx', 'weblogic', 'websphere'], 'Componente de servidor'),
    (['bios', 'firmware'], 'Firmware / BIOS'),
]


def categoria_software(title: str) -> str:
    t = title.lower()
    for keywords, cat in CATEGORIAS_SOFTWARE:
        if any(k in t for k in keywords):
            return cat
    return 'Otro software'


_RE_CVE = re.compile(r'CVE-\d{4}-\d{4,7}', re.IGNORECASE)
_RE_VERSION = re.compile(r'\b\d+(?:\.\d+){1,4}\.?x?\b')


def redactar_titulo(title: str) -> str:
    t = _RE_CVE.sub('(CVE omitido)', title)
    t = _RE_VERSION.sub('(versión omitida)', t)
    return t


def bucket_maquinas(n: int) -> str:
    if n < 100:
        return '< 100'
    if n < 1000:
        return '100 – 999'
    if n < 5000:
        return '1.000 – 4.999'
    return '≥ 5.000'


FACTORES_DORA = [
    {'id': 'severidad', 'nombre': 'Severidad estimada', 'max': 20,
     'normas': ['ISO_A88', 'NIS2_21e', 'DORA_RTS10']},
    {'id': 'exposicion', 'nombre': 'Exposición real', 'max': 20, 'normas': ['ISO_A59', 'DORA_8']},
    {'id': 'sla', 'nombre': 'Consumo del SLA', 'max': 20, 'normas': ['DORA_RTS10', 'NIS2_21f', 'ISO_91']},
    {'id': 'overdue', 'nombre': 'Situación de overdue', 'max': 15, 'normas': ['DORA_9', 'NIS2_21f']},
    {'id': 'critica', 'nombre': 'Criticidad del activo', 'max': 15, 'normas': ['DORA_8', 'DORA_9', 'ISO_A59']},
    {'id': 'tendencia', 'nombre': 'Tendencia', 'max': 10, 'normas': ['DORA_13', 'ISO_102', 'ISO_A816']},
]

SEVERIDAD_KEYWORDS = [
    ('remote code execution', 10.0), ('unauthenticated', 10.0), ('arbitrary code execution', 10.0),
    ('eol', 9.0), ('privilege escalation', 8.5),
    ('memory corruption', 8.0), ('use after free', 8.0), ('buffer overflow', 8.0),
    ('security update', 7.5), ('critical patch update', 7.5), ('multiple vulnerabilities', 7.5),
    ('injection', 7.0), ('denial of service', 6.0), ('not installed', 5.0), ('detected', 5.0),
]
SEVERIDAD_DEFAULT = 6.5


def severidad_dora(title: str) -> tuple:
    t = title.lower()
    for kw, score in SEVERIDAD_KEYWORDS:
        if kw in t:
            return score, kw
    return SEVERIDAD_DEFAULT, None


def puntuar_dora(title, maquinas, machines_total, dias_vida, overdue_count, vip, delta):
    sev_score, sev_kw = severidad_dora(title)
    sev_pts = round(sev_score * 2, 1)

    exp_pts = round(20 * math.log(max(maquinas, 1)) / math.log(max(machines_total, 2)), 1) if maquinas > 0 else 0.0

    sla_pts = round(20 * min(dias_vida / 30, 1) ** 2, 1) if dias_vida else 0.0

    overdue_pct = (overdue_count / maquinas * 100) if maquinas else 0.0
    overdue_pts = round(15 * min(overdue_pct / 100, 1), 1)

    if vip and maquinas:
        critica_pts = round(min(3.0 + 15 * (vip / maquinas), 15.0), 1)
    else:
        critica_pts = 0.0

    if delta is None:
        tendencia_pts = 0.0
    elif delta > 0:
        tendencia_pts = 10.0
    elif delta == 0:
        tendencia_pts = 6.0
    else:
        tendencia_pts = 0.0

    score = round(sev_pts + exp_pts + sla_pts + overdue_pts + critica_pts + tendencia_pts, 1)

    if score >= 75:
        banda, plazo, color = 'CRÍTICA', '48 horas', '#ef4444'
    elif score >= 60:
        banda, plazo, color = 'ALTA', '7 días', '#f5a623'
    elif score >= 40:
        banda, plazo, color = 'MEDIA', '30 días', '#b05cff'
    else:
        banda, plazo, color = 'BAJA', 'Ciclo normal', '#27c281'

    detalles = {
        'severidad': (f'Severidad {sev_score:.1f}/10 (por «{sev_kw}» en el título)' if sev_kw
                      else f'Severidad {sev_score:.1f}/10 (valor por defecto)'),
        'exposicion': f'{maquinas:,} máquinas vivas ({maquinas/machines_total*100:.1f}% del parque)'.replace(',', '.'),
        'sla': f'{dias_vida} días de vida' + (' · SLA INCUMPLIDO (peso máximo)' if dias_vida >= 30 else ''),
        'overdue': f'{overdue_count} detecciones overdue ({overdue_pct:.0f}%)',
        'critica': (f'{vip} máquina(s) VIP afectada(s)' if vip else 'Sin máquinas VIP afectadas'),
        'tendencia': ('Creciendo' if (delta or 0) > 0 else 'Estable' if delta == 0 else 'Bajando'),
    }
    puntos_por_id = {'severidad': sev_pts, 'exposicion': exp_pts, 'sla': sla_pts,
                      'overdue': overdue_pts, 'critica': critica_pts, 'tendencia': tendencia_pts}
    desglose = [{'id': f['id'], 'puntos': puntos_por_id[f['id']], 'detalle': detalles[f['id']],
                 'nombre': f['nombre'], 'max': f['max'], 'normas': f['normas']} for f in FACTORES_DORA]

    return {
        'score': score, 'banda': banda, 'plazo': plazo, 'color': color,
        'restantes': 30 - dias_vida, 'desglose': desglose,
    }


def filas_priorizacion(filas: list, machine_table: list, fecha: str,
                        vip_set: set, machines_total: int, deltas_previos: dict = None) -> list:
    por_qid_titulo = defaultdict(list)
    for r in filas:
        por_qid_titulo[(r['QID'], r['Title'])].append(r)

    salida = []
    for (qid, title), rs in por_qid_titulo.items():
        vistas = {}
        for r in rs:
            vistas.setdefault(r['norm'], r)
        rs_u = list(vistas.values())
        maquinas = len(rs_u)
        maquinas_brutas = len(rs)
        overdue = sum(1 for r in rs if _overdue_bool(r))
        vip = sum(1 for r in rs_u if r['norm'] in vip_set)
        dias_pub = [d for d in (_dias_publicada(r) for r in rs) if d is not None]
        dias_vida = max(dias_pub) if dias_pub else 0

        delta = None
        if deltas_previos is not None and qid in deltas_previos:
            delta = maquinas - deltas_previos[qid]

        puntuacion = puntuar_dora(title, maquinas, machines_total, dias_vida, overdue, vip, delta)

        entidades = sorted(set(r['Entidad'] for r in rs_u if r.get('Entidad')))
        subentidades = sorted(set(r['Subentidad'] for r in rs_u if r.get('Subentidad')))

        fila = {
            'titulo': title, 'qid': qid, 'maquinas': maquinas, 'maquinas_brutas': maquinas_brutas,
            'overdue': overdue, 'vip': vip, 'dias_vida': dias_vida, 'delta': delta if delta is not None else 0,
            'entidades': entidades, 'subentidades': subentidades,
            'motivos': [], 'modificadores': [],
            'maquinas_txt': bucket_maquinas(maquinas), 'maquinas_brutas_txt': bucket_maquinas(maquinas_brutas),
            'vip_txt': 'Sí' if vip else 'No',
            'delta_txt': ('Sube' if (delta or 0) > 0 else 'Baja' if (delta or 0) < 0 else 'Estable'),
        }
        fila.update(puntuacion)
        fila['normas'] = sorted({n for f in puntuacion['desglose'] for n in f['normas']})
        salida.append(fila)

    salida.sort(key=lambda r: -r['score'])
    for i, f in enumerate(salida, 1):
        f['rank'] = i
    return salida
