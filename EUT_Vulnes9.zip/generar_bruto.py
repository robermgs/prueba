r"""
Genera dashboard_bruto.html: una tabla con TODAS las vulnerabilidades,
mostrando detecciones EN BRUTO (sin deduplicar por máquina, igual que el
cruce manual en Excel) por entorno, y la variación respecto al día
anterior. Incluye buscador (por título o QID) y orden por columnas.

Mantiene su propio histórico (historico_bruto.json) con el total en bruto
por título y fecha, para poder calcular la variación cada día.

Uso:
    python3 generar_bruto.py SA.csv SG.csv 2026-09-02 \
        --historico ..\historico\historico_bruto.json \
        --out ..\dashboards\dashboard_bruto.html
"""
import argparse
import json
import sys

from core import cargar_datos, filas_bruto


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {'fechas': [], 'qids': {}}


PLANTILLA_HTML = r'''<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Detecciones en bruto</title>
<style>
  :root{ --bg:#0b1837; --card:#0f214b; --border:#1e3a6e; --text:#f0f4ff; --muted:#8899bb;
         --red:#ef4444; --green:#22c55e; --accent:#EC0000; }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);font-family:'Segoe UI',Arial,sans-serif}
  header{padding:24px 32px 12px}
  h1{margin:0 0 4px;font-size:24px}
  p.sub{margin:0;color:var(--muted);font-size:13px}
  .controles{display:flex;gap:12px;padding:0 32px 16px;flex-wrap:wrap;align-items:center}
  .controles input{background:var(--card);border:1px solid var(--border);color:var(--text);
    padding:8px 12px;border-radius:8px;font-size:14px;min-width:280px}
  .controles select{background:var(--card);border:1px solid var(--border);color:var(--text);
    padding:8px 12px;border-radius:8px;font-size:14px}
  .kpis{display:flex;gap:16px;padding:0 32px 16px;flex-wrap:wrap}
  .kpi{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:14px 20px;min-width:160px}
  .kpi .val{font-size:22px;font-weight:700}
  .kpi .lbl{font-size:12px;color:var(--muted)}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th,td{padding:8px 12px;border-bottom:1px solid var(--border);text-align:right}
  th:nth-child(1),th:nth-child(2),td:nth-child(1),td:nth-child(2){text-align:left}
  th{background:var(--card);cursor:pointer;user-select:none;position:sticky;top:0}
  th:hover{color:var(--accent)}
  tr:hover td{background:#132a5c}
  .pos{color:var(--red);font-weight:700}
  .neg{color:var(--green);font-weight:700}
  .zero{color:var(--muted)}
  main{padding:0 32px 40px}
</style>
</head>
<body>
<header>
  <h1>📊 Detecciones en bruto por vulnerabilidad</h1>
  <p class="sub">Snapshot {FECHA} · comparado con {FECHA_ANTERIOR} · cuenta FILAS (sin deduplicar por máquina) — mismo criterio que el cruce manual en Excel</p>
</header>
<div class="kpis">
  <div class="kpi"><div class="val">{N_VULNS}</div><div class="lbl">Vulnerabilidades</div></div>
  <div class="kpi"><div class="val">{TOTAL_HOY}</div><div class="lbl">Detecciones totales hoy</div></div>
  <div class="kpi"><div class="val">{N_SUBEN}</div><div class="lbl">Suben respecto a ayer</div></div>
  <div class="kpi"><div class="val">{N_BAJAN}</div><div class="lbl">Bajan respecto a ayer</div></div>
</div>
<div class="controles">
  <input type="text" id="buscar" placeholder="Buscar por título o QID...">
  <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:14px">
    <input type="checkbox" id="agrupar"> Agrupar por vulnerabilidad
  </label>
</div>
<main>
<table id="tabla">
<thead>
<tr>
  <th data-col="qid">QID</th>
  <th data-col="titulo">Vulnerabilidad</th>
  <th data-col="sgto">SGTO</th>
  <th data-col="santec">SANTEC</th>
  <th data-col="total">Total hoy</th>
  <th data-col="ayer">Total ayer</th>
  <th data-col="variacion">Variación</th>
</tr>
</thead>
<tbody id="tbody"></tbody>
</table>
</main>
<script>
const FILAS = {FILAS_JSON};

function num(n){ return n.toLocaleString('es-ES'); }

function render(filas){
  const tbody = document.getElementById('tbody');
  tbody.innerHTML = filas.map(r => {
    let cls = 'zero', signo = '';
    if (r.variacion > 0) { cls='pos'; signo='+'; }
    else if (r.variacion < 0) { cls='neg'; }
    return `<tr>
      <td>${r.qid}</td>
      <td>${r.titulo}</td>
      <td>${num(r.sgto)}</td>
      <td>${num(r.santec)}</td>
      <td>${num(r.total)}</td>
      <td>${r.ayer === null ? '—' : num(r.ayer)}</td>
      <td class="${cls}">${r.ayer === null ? '—' : signo + num(r.variacion)}</td>
    </tr>`;
  }).join('');
}

let ordenCol = 'total', ordenAsc = false;
function ordenar(col){
  if (ordenCol === col) ordenAsc = !ordenAsc; else { ordenCol = col; ordenAsc = false; }
  aplicar();
}
document.querySelectorAll('th[data-col]').forEach(th => {
  th.addEventListener('click', () => ordenar(th.dataset.col));
});

function agruparPorTitulo(filas){
  // Agrupa por coincidencia EXACTA (carácter a carácter) del texto de
  // 'titulo' — sin normalizar, sin trim extra, sin case-insensitive.
  const grupos = new Map();
  for (const r of filas){
    if (!grupos.has(r.titulo)){
      grupos.set(r.titulo, {
        qids: [], titulo: r.titulo, sgto: 0, santec: 0, total: 0,
        ayerSuma: 0, ayerHayDatos: false,
      });
    }
    const g = grupos.get(r.titulo);
    g.qids.push(r.qid);
    g.sgto += r.sgto;
    g.santec += r.santec;
    g.total += r.total;
    if (r.ayer !== null){
      g.ayerSuma += r.ayer;
      g.ayerHayDatos = true;
    }
  }
  return Array.from(grupos.values()).map(g => {
    const ayer = g.ayerHayDatos ? g.ayerSuma : null;
    // La variación del grupo se RECALCULA (hoy - ayer), no se suman las
    // variaciones individuales, para que sea robusta ante cambios futuros
    // en la fórmula de variación.
    const variacion = ayer === null ? null : (g.total - ayer);
    return {
      qid: `(${g.qids.length} vulnerabilidad${g.qids.length === 1 ? '' : 'es'})`,
      titulo: g.titulo, sgto: g.sgto, santec: g.santec, total: g.total,
      ayer: ayer, variacion: variacion,
    };
  });
}

function aplicar(){
  const q = document.getElementById('buscar').value.toLowerCase();
  let filas = FILAS.filter(r => !q || r.titulo.toLowerCase().includes(q) || r.qid.includes(q));
  if (document.getElementById('agrupar').checked){
    filas = agruparPorTitulo(filas);
  }
  filas.sort((a,b) => {
    let va = a[ordenCol], vb = b[ordenCol];
    if (va === null) va = -Infinity;
    if (vb === null) vb = -Infinity;
    if (typeof va === 'string') return ordenAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    return ordenAsc ? va - vb : vb - va;
  });
  render(filas);
}

document.getElementById('buscar').addEventListener('input', aplicar);
document.getElementById('agrupar').addEventListener('change', aplicar);
aplicar();
</script>
</body>
</html>
'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--historico', default='historico_bruto.json')
    ap.add_argument('--out', default='dashboard_bruto.html')
    args = ap.parse_args()

    hist = cargar_historico(args.historico)

    print('Cargando CSV...')
    filas_csv = cargar_datos(args.sa_csv, args.sg_csv)

    print('Calculando detecciones en bruto...')
    bruto_hoy = filas_bruto(filas_csv)

    fechas_previas = sorted(f for f in hist['fechas'] if f < args.fecha)
    fecha_ayer = fechas_previas[-1] if fechas_previas else None

    hist.setdefault('qids', {})  # compatibilidad con históricos antiguos (guardaban por título)

    filas_out = []
    n_suben = n_bajan = 0
    for r in bruto_hoy:
        ayer = hist['qids'].get(r['qid'], {}).get(fecha_ayer) if fecha_ayer else None
        variacion = (r['total'] - ayer) if ayer is not None else None
        if variacion is not None:
            if variacion > 0:
                n_suben += 1
            elif variacion < 0:
                n_bajan += 1
        filas_out.append({
            'qid': r['qid'], 'titulo': r['titulo'], 'sgto': r['sgto'], 'santec': r['santec'],
            'total': r['total'], 'ayer': ayer, 'variacion': variacion,
        })

    for r in bruto_hoy:
        hist['qids'].setdefault(r['qid'], {})[args.fecha] = r['total']
    if args.fecha not in hist['fechas']:
        hist['fechas'].append(args.fecha)
        hist['fechas'].sort()

    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist, f, ensure_ascii=False)

    html = (PLANTILLA_HTML
            .replace('{FECHA}', args.fecha)
            .replace('{FECHA_ANTERIOR}', fecha_ayer or '(sin día anterior)')
            .replace('{N_VULNS}', str(len(filas_out)))
            .replace('{TOTAL_HOY}', f"{sum(r['total'] for r in filas_out):,}".replace(',', '.'))
            .replace('{N_SUBEN}', str(n_suben))
            .replace('{N_BAJAN}', str(n_bajan))
            .replace('{FILAS_JSON}', json.dumps(filas_out, ensure_ascii=False)))

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(html)

    print('Listo:', args.out)
    print(f'{len(filas_out)} vulnerabilidades | {n_suben} suben | {n_bajan} bajan')


if __name__ == '__main__':
    sys.exit(main())
