r"""
Para cada vulnerabilidad que HOY está en overdue, calcula la fecha exacta
en la que entró en overdue (el día que Dias_Publicada llegó a 31). No
hace falta histórico día a día para esto: el propio CSV de hoy ya trae
Dias_Publicada, así que basta con restar hacia atrás desde la fecha de
hoy.

Uso:
    python3 generar_fechas_overdue.py SA.csv SG.csv 2026-09-03 \
        --out ..\resumenes\fechas_entrada_overdue_2026-09-03.csv
"""
import argparse
import csv
import sys

from core import cargar_datos, _dias_publicada, _overdue_bool, fecha_entrada_overdue


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--out', default='fechas_entrada_overdue.csv')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)

    vistas = {}
    for r in filas:
        if not _overdue_bool(r):
            continue
        clave = (r['norm'], r['QID'])
        if clave in vistas:
            continue
        dp = _dias_publicada(r)
        fecha_entrada = fecha_entrada_overdue(args.fecha, dp)
        vistas[clave] = {
            'norm': r['norm'], 'qid': r['QID'], 'title': r.get('Title', ''),
            'entidad': r.get('Entidad', ''), 'subentidad': r.get('Subentidad', ''),
            'env': r['env'], 'dias_publicada': dp, 'fecha_entrada_overdue': fecha_entrada,
            'dias_en_overdue': (dp - 31) if dp is not None else None,
        }

    filas_out = list(vistas.values())
    # más antiguas primero = las más urgentes / las que más tiempo llevan overdue
    filas_out.sort(key=lambda r: (r['fecha_entrada_overdue'] or '9999-99-99'))

    print(f'{len(filas_out)} combinación(es) máquina+vulnerabilidad en overdue hoy.')

    with open(args.out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['Entorno', 'Entidad', 'Subentidad', 'Netbios', 'QID', 'Titulo',
                    'Dias_Publicada', 'Fecha_Entrada_Overdue', 'Dias_En_Overdue'])
        for r in filas_out:
            w.writerow([r['env'], r['entidad'], r['subentidad'], r['norm'], r['qid'], r['title'],
                        r['dias_publicada'], r['fecha_entrada_overdue'] or '', r['dias_en_overdue']])

    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())
