r"""
Genera indice_busqueda.js: un pequeño índice con todas las máquinas y
vulnerabilidades del día, para que el buscador global de base.html pueda
encontrarlas y enlazar directo a su ficha, sin tener que abrir cada panel
a mano para buscar.

Se guarda como variable JS (const INDICE_BUSQUEDA = [...]) en vez de JSON
suelto, porque abrir un .json con fetch() falla en muchos navegadores
cuando se abre con file:// (CORS) — con un <script src="..."> no hay ese
problema, es el mismo truco que ya usan los demás paneles.

Uso:
    python3 generar_indice_busqueda.py SA.csv SG.csv 2026-09-03 \
        --out ..\dashboards\indice_busqueda.js
"""
import argparse
import json
import sys

from core import cargar_datos, tabla_maquinas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--out', default='indice_busqueda.js')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas, fecha_informe=args.fecha)

    print('Construyendo índice...')
    indice = []
    for m in mt:
        indice.append({
            'tipo': 'maquina', 'clave': m['machine'],
            'etiqueta': f"{m['machine']} ({m['ent']}/{m['sub']})",
            'panel': 'dashboard_maquina_detalle.html', 'param': 'm',
        })

    titulos_vistos = set()
    for r in filas:
        if r['Title'] not in titulos_vistos:
            titulos_vistos.add(r['Title'])
            indice.append({
                'tipo': 'vulnerabilidad', 'clave': r['Title'],
                'etiqueta': f"{r['Title']} (QID {r['QID']})",
                'panel': 'dashboard_vuln_detalle.html', 'param': 't',
            })

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(f'const INDICE_BUSQUEDA_FECHA = "{args.fecha}";\n')
        f.write('const INDICE_BUSQUEDA = ' + json.dumps(indice, ensure_ascii=False) + ';\n')

    print('Listo:', args.out, f'({len(indice)} entradas: {len(mt)} máquinas, {len(titulos_vistos)} vulnerabilidades)')


if __name__ == '__main__':
    sys.exit(main())
