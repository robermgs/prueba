r"""
Informe de cumplimiento SLA por entidad: de todas las vulnerabilidades
que se han detectado como "arregladas" (ver generar_resumen_fixed.py),
qué % se arregló dentro del plazo de 30 días y qué % se arregló tarde
(ya en overdue), desglosado por entidad. Pensado para reporting de
cumplimiento tipo DORA/NIS2.

Recorre todos los resumen_maquinas_fixed_*.csv que haya en la carpeta de
resúmenes (normalmente los últimos 60 días, antes de que la rotación los
archive) y agrega los datos. Si quieres un periodo distinto, apunta
--desde a la fecha que quieras.

Uso:
    python3 generar_informe_sla.py ..\resumenes 2026-09-03 --desde 2026-08-01
"""
import argparse
import csv
import glob
import os
import re
import sys
from collections import defaultdict

PATRON_FECHA = re.compile(r'resumen_maquinas_fixed_(\d{4}-\d{2}-\d{2})\.csv$')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('carpeta_resumenes')
    ap.add_argument('fecha_hoy')
    ap.add_argument('--desde', default=None, help='Fecha mínima a incluir (YYYY-MM-DD). Si no se indica, coge todo lo que haya.')
    ap.add_argument('--out', default='informe_sla.txt')
    args = ap.parse_args()

    ficheros = []
    for path in glob.glob(os.path.join(args.carpeta_resumenes, 'resumen_maquinas_fixed_*.csv')):
        m = PATRON_FECHA.search(os.path.basename(path))
        if not m:
            continue
        fecha = m.group(1)
        if args.desde and fecha < args.desde:
            continue
        ficheros.append((fecha, path))
    ficheros.sort()

    if not ficheros:
        print('No he encontrado ningún resumen_maquinas_fixed_*.csv en', args.carpeta_resumenes)
        return 1

    print(f'Agregando {len(ficheros)} fichero(s), de {ficheros[0][0]} a {ficheros[-1][0]}...')

    por_entidad = defaultdict(lambda: {'total': 0, 'cumplido': 0, 'incumplido': 0, 'sin_dato': 0})
    total_global = {'total': 0, 'cumplido': 0, 'incumplido': 0, 'sin_dato': 0}

    for fecha, path in ficheros:
        with open(path, 'r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f, delimiter=';')
            if 'Cumplio_SLA_30_dias' not in (reader.fieldnames or []):
                continue  # fichero de una versión anterior sin esta columna, se ignora
            for r in reader:
                ent = r.get('Entidad') or 'NO'
                por_entidad[ent]['total'] += 1
                total_global['total'] += 1
                if r['Cumplio_SLA_30_dias'] == 'Sí':
                    por_entidad[ent]['cumplido'] += 1
                    total_global['cumplido'] += 1
                elif r['Cumplio_SLA_30_dias'] == 'No':
                    por_entidad[ent]['incumplido'] += 1
                    total_global['incumplido'] += 1
                else:
                    por_entidad[ent]['sin_dato'] += 1
                    total_global['sin_dato'] += 1

    if total_global['total'] == 0:
        print('No hay filas con datos de cumplimiento SLA en el periodo indicado '
              '(puede que los ficheros sean de antes de tener esta columna).')
        return 0

    filas_out = []
    for ent, v in por_entidad.items():
        base = v['cumplido'] + v['incumplido']
        pct = round(100 * v['cumplido'] / base, 1) if base else None
        filas_out.append({'ent': ent, 'pct': pct, **v})
    filas_out.sort(key=lambda x: (x['pct'] is None, x['pct'] if x['pct'] is not None else 0))

    pct_global = round(100 * total_global['cumplido'] / (total_global['cumplido'] + total_global['incumplido']), 1) \
        if (total_global['cumplido'] + total_global['incumplido']) else None

    lineas = [
        f'INFORME DE CUMPLIMIENTO SLA (30 días) POR ENTIDAD',
        f'Periodo: {ficheros[0][0]} a {ficheros[-1][0]}',
        '=' * 60,
        '',
        f'GLOBAL: {pct_global}% cumplimiento ({num(total_global["cumplido"])} dentro de plazo, '
        f'{num(total_global["incumplido"])} fuera de plazo, {num(total_global["sin_dato"])} sin dato de fecha)',
        '',
        '--- Por entidad (de peor a mejor cumplimiento) ---',
        '',
    ]
    for f in filas_out:
        pct_txt = f"{f['pct']}%" if f['pct'] is not None else 'N/D (sin base suficiente)'
        lineas.append(f"  {f['ent']:<20} {pct_txt:>10}   "
                       f"({num(f['cumplido'])} en plazo / {num(f['incumplido'])} tarde"
                       + (f" / {num(f['sin_dato'])} sin dato" if f['sin_dato'] else '') + ')')

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)
    print(f'Cumplimiento global: {pct_global}%')
    return 0


def num(n):
    return f'{n:,}'.replace(',', '.')


if __name__ == '__main__':
    sys.exit(main())
