"""
Genera (o actualiza) dashboard_maquina_detalle.html a partir de SA.csv, SG.csv,
Equipos_VIP.csv y Estado_vulnes_1.csv.

Los campos 'estado' (tickets, seguimiento) y 'vip' salen de fuentes reales:
- vip: Equipos_VIP.csv (lista de máquinas VIP)
- estado: Estado_vulnes_1.csv (seguimiento manual por título de vulnerabilidad)
Si un título/máquina no aparece en esos ficheros, se usa 'Sin estado' / vip=False.

Uso:
    python3 generar_maquina_detalle.py SA.csv SG.csv Equipos_VIP.csv Estado_vulnes_1.csv 2026-08-26 \\
        --template dashboard_maquina_detalle.html \\
        --historico historico_maquina_detalle.json \\
        --out dashboard_maquina_detalle_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import cargar_datos, tabla_maquinas, cargar_vip, cargar_estados


def extraer_const_span(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\}|\[.*?\]);\r?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def sembrar_historico_desde_html(template_path):
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    span_f = extraer_const_span(content, 'FECHAS')
    fechas = json.loads(content[span_f[0]:span_f[1]])
    span_m = extraer_const_span(content, 'MACHINE_DETAIL')
    md = json.loads(content[span_m[0]:span_m[1]])
    return {'fechas': fechas, 'machine_detail': md}


def construir_vulns_por_maquina(filas):
    """dict {norm: [{title, overdue}, ...]} a partir del CSV de hoy."""
    from collections import defaultdict
    vistas = {}
    for r in filas:
        vistas.setdefault((r['norm'], r['Title']), r)
    out = defaultdict(list)
    for (norm, title), r in vistas.items():
        overdue = (r.get('Overdue') or 'FALSO').strip().upper() == 'VERDADERO'
        out[norm].append({'title': title, 'overdue': overdue})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('vip_csv')
    ap.add_argument('estados_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_maquina_detalle.html')
    ap.add_argument('--historico', default='historico_maquina_detalle.json')
    ap.add_argument('--out', default='dashboard_maquina_detalle_NUEVO.html')
    args = ap.parse_args()

    hist = cargar_historico(args.historico)
    if hist is None:
        print(f'No hay histórico previo, lo siembro desde {args.template}...')
        hist = sembrar_historico_desde_html(args.template)

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas, fecha_informe=args.fecha)
    vulns_por_maquina = construir_vulns_por_maquina(filas)
    vip_set = cargar_vip(args.vip_csv)
    estados = cargar_estados(args.estados_csv)

    print('Construyendo MACHINE_DETAIL de hoy (vip/estado reales)...')
    detalle_hoy = {}
    for r in mt:
        norm = r['machine']
        vulns = []
        for v in vulns_por_maquina.get(norm, []):
            vulns.append({
                'title': v['title'],
                'overdue': v['overdue'],
                'estado': estados.get(v['title'], 'Sin estado'),
            })
        detalle_hoy[norm] = {
            'machine': norm,
            'env': r['env'], 'ent': r['ent'], 'sub': r['sub'],
            'vip': norm in vip_set,
            'cruce': r['cruce'], 'sccm': r['c_sccm'], 'da': r['c_da'], 'minerva': r['c_min'],
            'dias_sin_reportar': r['dias_sin_reportar'],
            'vulns': vulns,
        }

    hist['machine_detail'] = {args.fecha: detalle_hoy}  # solo se guarda detalle completo del último día
    if args.fecha not in hist['fechas']:
        hist['fechas'].append(args.fecha)
        hist['fechas'].sort()

    print('Guardando histórico...')
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist, f, ensure_ascii=False)

    print('Generando HTML final...')
    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()
    for name, value in [('FECHAS', hist['fechas']), ('MACHINE_DETAIL', hist['machine_detail'])]:
        span = extraer_const_span(content, name)
        content = content[:span[0]] + json.dumps(value, ensure_ascii=False) + content[span[1]:]
    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print('Máquinas:', len(detalle_hoy))


if __name__ == '__main__':
    sys.exit(main())
