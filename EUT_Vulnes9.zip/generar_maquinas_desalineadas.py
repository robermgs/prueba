"""
Genera (o actualiza) dashboard_maquinas_desalineadas.html a partir de
SA.csv y SG.csv.

Este panel guarda una fila POR MÁQUINA Y POR DÍA en la constante DATA
(histórico completo, no solo el último día), más un resumen HISTORY con
el nº de máquinas en cada rango de "días sin reportar" (hoy / 1-2 / 3-10 / >10).

Uso:
    python3 generar_maquinas_desalineadas.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_maquinas_desalineadas.html \\
        --historico historico_desalineadas.json \\
        --out dashboard_maquinas_desalineadas_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import cargar_datos, tabla_maquinas, rango_dias

MAX_DIAS = 60  # días de histórico que se conservan; el resto se descarta


def extraer_const_span(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\}|\[.*?\]);\r?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def sembrar_historico_desde_html(template_path):
    print('  leyendo plantilla completa (puede tardar, el fichero es grande)...')
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    span_data = extraer_const_span(content, 'DATA')
    span_hist = extraer_const_span(content, 'HISTORY')
    data_obj = json.loads(content[span_data[0]:span_data[1]])
    history = json.loads(content[span_hist[0]:span_hist[1]])
    return {'data': data_obj['rows'], 'history': history,
            'fechas': list(data_obj['fechas'])}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_maquinas_desalineadas.html')
    ap.add_argument('--historico', default='historico_desalineadas.json')
    ap.add_argument('--out', default='dashboard_maquinas_desalineadas_NUEVO.html')
    args = ap.parse_args()

    hist = cargar_historico(args.historico)
    if hist is None:
        print(f'No hay histórico previo, lo siembro desde {args.template}...')
        hist = sembrar_historico_desde_html(args.template)

    print('Cargando CSV...')
    filas_csv = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas_csv, fecha_informe=args.fecha)
    for r in mt:
        r['range'] = rango_dias(r['dias_sin_reportar'])

    filas_hoy = []
    for r in mt:
        filas_hoy.append({
            'fecha': args.fecha,
            'env': r['env'],
            'ent': r['ent'],
            'sub': r['sub'],
            'machine': r['machine'],
            'activity': r['activity'],
            'days_without_report': r['dias_sin_reportar'],
            'range': r['range'],
            'sccm': r['c_sccm'],
            'da': r['c_da'],
            'minerva': r['c_min'],
            'cruce': r['cruce'],
        })

    # quitar filas viejas de la misma fecha (por si se relanza) y añadir las nuevas
    hist['data'] = [r for r in hist['data'] if r['fecha'] != args.fecha] + filas_hoy
    if args.fecha not in hist['fechas']:
        hist['fechas'].append(args.fecha)
        hist['fechas'].sort()

    from collections import Counter
    counts = Counter(r['range'] for r in mt)
    if args.fecha not in hist['history']['labels']:
        hist['history']['labels'] = hist['fechas']
        for k in ('hoy', 'r12', 'r310', 'gt10'):
            hist['history'].setdefault(k, [])
            hist['history'][k].append(int(counts.get(k, 0)))
    else:
        idx = hist['history']['labels'].index(args.fecha)
        for k in ('hoy', 'r12', 'r310', 'gt10'):
            hist['history'][k][idx] = int(counts.get(k, 0))

    # --- Recorte de histórico: nos quedamos solo con los últimos MAX_DIAS ---
    # (si no, el fichero crece ~49.000 filas cada día y acaba pesando cientos
    # de MB, como pasó con dashboard_overdue_json.html)
    if len(hist['fechas']) > MAX_DIAS:
        fechas_a_mantener = set(hist['fechas'][-MAX_DIAS:])
        print(f'Recortando histórico a los últimos {MAX_DIAS} días '
              f'({len(hist["fechas"]) - MAX_DIAS} día(s) fuera)...')
        hist['data'] = [r for r in hist['data'] if r['fecha'] in fechas_a_mantener]
        idxs = [i for i, f in enumerate(hist['fechas']) if f in fechas_a_mantener]
        hist['fechas'] = [hist['fechas'][i] for i in idxs]
        hist['history']['labels'] = hist['fechas']
        for k in ('hoy', 'r12', 'r310', 'gt10'):
            hist['history'][k] = [hist['history'][k][i] for i in idxs]

    print('Guardando histórico (esto puede tardar por el tamaño)...')
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist, f, ensure_ascii=False)

    print('Generando HTML final (escribiendo por partes para no saturar memoria)...')
    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()

    span_data = extraer_const_span(content, 'DATA')
    span_hist = extraer_const_span(content, 'HISTORY')
    # Sustituimos primero el bloque que va DESPUÉS (HISTORY), así el offset
    # de DATA (que va antes) sigue siendo válido.
    nuevo_history = json.dumps(hist['history'], ensure_ascii=False)
    content_con_history = content[:span_hist[0]] + nuevo_history + content[span_hist[1]:]
    del content  # liberar memoria cuanto antes

    with open(args.out, 'w', encoding='utf-8') as out:
        out.write(content_con_history[:span_data[0]])
        out.write('{"fechas": ')
        out.write(json.dumps(hist['fechas'], ensure_ascii=False))
        out.write(', "rows": [')
        for i, r in enumerate(hist['data']):
            if i:
                out.write(',')
            out.write(json.dumps(r, ensure_ascii=False))
        out.write(']}')
        out.write(content_con_history[span_data[1]:])

    print(f'Listo: {args.out}')
    print('Rango hoy:', dict(counts))


if __name__ == '__main__':
    sys.exit(main())
