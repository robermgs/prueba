r"""
Detecta máquinas "fantasma": llevan --umbral-dias (por defecto 30) días o
más sin actividad reportada a Qualys, pero siguen apareciendo en el CSV
(y por tanto contando en los totales) como si estuvieran activas. Suele
ser indicio de equipos dados de baja/reemplazados que nadie ha quitado
del scan.

Incluye el estado de SCCM/DA/Minerva de cada una, para ver de un vistazo
si de verdad parecen "muertas" del todo (ko/ko/ko) o si siguen vivas en
algún otro sistema aunque Qualys no las vea.

Uso:
    python3 generar_maquinas_fantasma.py SA.csv SG.csv 2026-09-03 \
        --umbral-dias 30 --out ..\resumenes\maquinas_fantasma_2026-09-03.csv
"""
import argparse
import csv
import sys

from core import cargar_datos, tabla_maquinas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--umbral-dias', type=int, default=30)
    ap.add_argument('--out', default='maquinas_fantasma.csv')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas, fecha_informe=args.fecha)

    fantasma = [m for m in mt if m['dias_sin_reportar'] is not None and m['dias_sin_reportar'] >= args.umbral_dias]
    fantasma.sort(key=lambda m: -m['dias_sin_reportar'])

    print(f'{len(fantasma)} máquina(s) llevan {args.umbral_dias}+ días sin reportar '
          f'(de {len(mt)} máquinas totales).')

    with open(args.out, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['Dias_Sin_Reportar', 'Netbios', 'Asset_Id', 'Entidad', 'Subentidad', 'Vulns',
                    'Ultima_Actividad', 'Estado_SCCM', 'Estado_DA', 'Estado_Minerva', 'Cruce'])
        for m in fantasma:
            w.writerow([m['dias_sin_reportar'], m['machine'], m['asset_id'], m['ent'], m['sub'], m['count'],
                        m['activity'] or '', m['c_sccm'], m['c_da'], m['c_min'], m['cruce']])

    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())

