"""
Genera (o actualiza) dashboard_no_overdue.html a partir de SA.csv y SG.csv.

DATA = {fechas, rows (solo NO overdue, con new_count), rows_all (todas,
sin new_count), remediation_by_title (notas manuales del analista — NO
se tocan, se conservan tal cual venían)}.

Uso:
    python3 generar_no_overdue.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_no_overdue.html \\
        --historico historico_no_overdue.json \\
        --out dashboard_no_overdue_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import cargar_datos, filas_por_grupo_titulo


def extraer_const_span(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\}|\[.*?\]);\r?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def sembrar_historico_desde_html(template_path):
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    span = extraer_const_span(content, 'DATA')
    data = json.loads(content[span[0]:span[1]])
    return data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_no_overdue.html')
    ap.add_argument('--historico', default='historico_no_overdue.json')
    ap.add_argument('--out', default='dashboard_no_overdue_NUEVO.html')
    args = ap.parse_args()

    data = cargar_historico(args.historico)
    if data is None:
        print(f'No hay histórico previo, lo siembro desde {args.template}...')
        data = sembrar_historico_desde_html(args.template)

    print('Cargando CSV...')
    df = cargar_datos(args.sa_csv, args.sg_csv)

    fechas_previas = sorted(f for f in data['fechas'] if f < args.fecha)
    counts_previos = None
    if fechas_previas:
        fecha_ant = fechas_previas[-1]
        counts_previos = {
            (r['env'], r['ent'], r['sub'], r['title']): r['count']
            for r in data['rows'] if r['fecha'] == fecha_ant
        }

    print('Calculando filas (no overdue)...')
    rows_hoy = filas_por_grupo_titulo(df, args.fecha, solo_no_overdue=True,
                                       counts_previos=counts_previos)
    print('Calculando filas (todas)...')
    rows_all_hoy = filas_por_grupo_titulo(df, args.fecha, solo_no_overdue=False)

    data['rows'] = [r for r in data['rows'] if r['fecha'] != args.fecha] + rows_hoy
    data['rows_all'] = [r for r in data['rows_all'] if r['fecha'] != args.fecha] + rows_all_hoy
    if args.fecha not in data['fechas']:
        data['fechas'].append(args.fecha)
        data['fechas'].sort()
    # remediation_by_title es contenido manual del analista: NO se toca

    print('Guardando histórico...')
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)

    print('Generando HTML final...')
    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()
    span = extraer_const_span(content, 'DATA')
    content = content[:span[0]] + json.dumps(data, ensure_ascii=False) + content[span[1]:]
    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print('Filas no-overdue hoy:', len(rows_hoy), '| Filas todas hoy:', len(rows_all_hoy))


if __name__ == '__main__':
    sys.exit(main())
