"""
Genera (o actualiza) dashboard_overdue_json.html a partir de SA.csv y SG.csv.

OVERDUE_DATA = {generated_at, latest_date, previous_date, rows}. 'rows' es
un log acumulativo (una fila por máquina+título overdue, por día). Es
DEMASIADO grande para cargarlo entero con json.loads (se queda sin
memoria) — así que este script NO parsea todo el JSON: localiza el bloque
de datos por texto y añade las filas nuevas justo antes del cierre del
array, sin tocar las filas antiguas.

IMPORTANTE: trabajamos en BINARIO (bytes), no en texto. Si se lee el
fichero como texto normal, Python necesita hasta 4 bytes de memoria por
carácter en cuanto aparece un acento o una "ñ" en todo el fichero — un
HTML de 460 MB en disco puede llegar a ocupar más de 2 GB en memoria así.
En binario, ocupa lo mismo que pesa en disco.

Recorta además el histórico a los últimos MAX_DIAS días, para que el
fichero no crezca sin límite (por eso llegó a pesar casi 500 MB).

Uso:
    python3 generar_overdue_json.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_overdue_json.html \\
        --out dashboard_overdue_json_NUEVO.html
"""
import argparse
import gc
import json
import re
import sys
from datetime import datetime, timedelta

from core import cargar_datos, filas_overdue

MAX_DIAS_DEFECTO = 30  # días de histórico que se conservan por defecto; el resto se descarta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_overdue_json.html')
    ap.add_argument('--out', default='dashboard_overdue_json_NUEVO.html')
    ap.add_argument('--max-dias', type=int, default=MAX_DIAS_DEFECTO,
                     help=f'Días de histórico a conservar (por defecto {MAX_DIAS_DEFECTO})')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    print('Calculando filas overdue de hoy...')
    filas_hoy = filas_overdue(filas, args.fecha)
    print(f'{len(filas_hoy)} filas overdue hoy')
    del filas
    gc.collect()

    print('Leyendo la plantilla en binario (fichero grande, puede tardar)...')
    with open(args.template, 'rb') as f:
        content = f.read()

    m = re.search(rb'const OVERDUE_DATA\s*=\s*(\{.*?\});\r?\n', content, re.S)
    if not m:
        raise ValueError('No se encontró OVERDUE_DATA en la plantilla')
    start, end = m.span(1)

    m_rows = re.search(rb'"rows"\s*:\s*\[', content[start:start + 2000])
    if not m_rows:
        raise ValueError('No se encontró "rows": [ dentro de OVERDUE_DATA')
    inicio_filas = start + m_rows.end()

    cabecera_vieja = content[start:inicio_filas].decode('utf-8')
    m_latest = re.search(r'"latest_date":\s*"([^"]*)"', cabecera_vieja)
    latest_anterior = m_latest.group(1) if m_latest else None

    cabecera_nueva = re.sub(r'"generated_at":\s*"[^"]*"',
                             f'"generated_at": "{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"',
                             cabecera_vieja, count=1)
    cabecera_nueva = re.sub(r'"latest_date":\s*"[^"]*"',
                             f'"latest_date": "{args.fecha}"', cabecera_nueva, count=1)
    cabecera_nueva = re.sub(r'"previous_date":\s*"[^"]*"',
                             f'"previous_date": "{latest_anterior}"', cabecera_nueva, count=1)
    cabecera_nueva_b = cabecera_nueva.encode('utf-8')

    if content[end - 2:end] != b']}':
        raise ValueError('El bloque OVERDUE_DATA no termina como se esperaba (]}}); revisar a mano')

    # --- Recorte de histórico: descartamos filas más viejas que MAX_DIAS ---
    # Las filas están en orden cronológico (cada día se añade al final), así
    # que buscamos por texto el punto donde empiezan las fechas a mantener,
    # sin necesidad de parsear los millones de filas.
    fecha_dt = datetime.strptime(args.fecha, '%Y-%m-%d')
    cutoff = (fecha_dt - timedelta(days=args.max_dias)).strftime('%Y-%m-%d')
    corte = inicio_filas
    print(f'Buscando el punto de corte para conservar solo desde {cutoff}...')
    patron_fecha = re.compile(rb'\{"fecha": "(\d{4}-\d{2}-\d{2})"')
    cutoff_b = cutoff.encode('ascii')
    encontrado = False
    for pm in patron_fecha.finditer(content, inicio_filas, end - 2):
        if pm.group(1) >= cutoff_b:
            corte = pm.start()
            encontrado = True
            break
    if not encontrado:
        corte = end - 2  # todas las filas son más viejas que el corte (raro)
    if corte > inicio_filas:
        print(f'  recortando filas anteriores a {cutoff} (no se vuelven a escribir)')

    print('Escribiendo HTML final por partes (sin cargarlo todo en memoria)...')
    with open(args.out, 'wb') as out:
        out.write(content[:start])
        out.write(cabecera_nueva_b)
        out.write(content[corte:end - 2])  # filas dentro de la ventana, tal cual
        if filas_hoy:
            out.write(b',')
            out.write(','.join(json.dumps(r, ensure_ascii=False) for r in filas_hoy).encode('utf-8'))
        out.write(content[end - 2:])

    print(f'Listo: {args.out}')
    print(f'Filas overdue añadidas hoy ({args.fecha}): {len(filas_hoy)}')


if __name__ == '__main__':
    sys.exit(main())
