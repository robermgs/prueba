"""
Genera (o actualiza) priorizacion_OPERATIVA.html, priorizacion_DIRECCION.html
y priorizacion_PUBLICA.html a partir de SA.csv, SG.csv y Equipos_VIP.csv.

Usa el motor de scoring DORA reconstruido en core.puntuar_dora (validado
contra las 363 filas reales de priorizacion_OPERATIVA.html: banda de
riesgo correcta en el 100% de los casos, score dentro de margen en el
96,7% — el resto son inconsistencias que ya existían en el fichero
original, no del motor).

Uso:
    python3 generar_priorizacion.py SA.csv SG.csv Equipos_VIP.csv 2026-08-26 \\
        --historico historico_priorizacion.json \\
        --template-operativa priorizacion_OPERATIVA.html \\
        --template-direccion priorizacion_DIRECCION.html \\
        --template-publica priorizacion_PUBLICA.html \\
        --outdir salida/
"""
import argparse
import copy
import json
import os
import re
import sys

from core import (cargar_datos, tabla_maquinas, cargar_vip, filas_priorizacion,
                   redactar_titulo, categoria_software, bucket_maquinas)


def extraer_const_span(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\});.*?\n', content, re.S)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def construir_direccion(filas_operativa):
    filas = copy.deepcopy(filas_operativa)
    for f in filas:
        f['titulo'] = redactar_titulo(f['titulo'])
        f['maquinas_brutas'] = 0  # no se enseña el dato fino
        f['vip_txt'] = 'Sí' if f['vip'] else 'No'
        f.pop('qid', None)
    return filas


def construir_publica(filas_operativa):
    filas = copy.deepcopy(filas_operativa)
    for f in filas:
        cat = categoria_software(f['titulo'])
        f['titulo'] = f"Vulnerabilidad {f['rank']:02d} · {cat}"
        f['entidades'] = []
        f['subentidades'] = []
        f['vip'] = 0
        f['vip_txt'] = 'No'
        f.pop('qid', None)
    return filas


def escribir_html(template_path, out_path, d_dict):
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    span = extraer_const_span(content, 'D')
    content = content[:span[0]] + json.dumps(d_dict, ensure_ascii=False) + content[span[1]:]
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(content)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('vip_csv')
    ap.add_argument('fecha')
    ap.add_argument('--historico', default='historico_priorizacion.json')
    ap.add_argument('--template-operativa', default='priorizacion_OPERATIVA.html')
    ap.add_argument('--template-direccion', default='priorizacion_DIRECCION.html')
    ap.add_argument('--template-publica', default='priorizacion_PUBLICA.html')
    ap.add_argument('--outdir', default='.')
    args = ap.parse_args()

    hist = cargar_historico(args.historico) or {'deltas': {}}

    print('Cargando CSV...')
    filas_csv = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas_csv, fecha_informe=args.fecha)
    vip_set = cargar_vip(args.vip_csv)
    machines_total = len(mt)

    print('Calculando FILAS con el motor DORA...')
    filas = filas_priorizacion(filas_csv, mt, args.fecha, vip_set, machines_total,
                                deltas_previos=hist['deltas'])

    hist['deltas'] = {qid: f['maquinas'] for f in filas for qid in [f['qid']]}
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist, f, ensure_ascii=False)

    os.makedirs(args.outdir, exist_ok=True)

    print('Generando OPERATIVA...')
    with open(args.template_operativa, 'r', encoding='utf-8') as f:
        content = f.read()
    span = extraer_const_span(content, 'D')
    d_op = json.loads(content[span[0]:span[1]])
    d_op['FILAS'] = filas
    escribir_html(args.template_operativa, os.path.join(args.outdir, 'priorizacion_OPERATIVA_NUEVO.html'), d_op)

    print('Generando DIRECCION (títulos redactados)...')
    with open(args.template_direccion, 'r', encoding='utf-8') as f:
        content = f.read()
    span = extraer_const_span(content, 'D')
    d_di = json.loads(content[span[0]:span[1]])
    d_di['FILAS'] = construir_direccion(filas)
    escribir_html(args.template_direccion, os.path.join(args.outdir, 'priorizacion_DIRECCION_NUEVO.html'), d_di)

    print('Generando PUBLICA (títulos anonimizados)...')
    with open(args.template_publica, 'r', encoding='utf-8') as f:
        content = f.read()
    span = extraer_const_span(content, 'D')
    d_pu = json.loads(content[span[0]:span[1]])
    d_pu['FILAS'] = construir_publica(filas)
    escribir_html(args.template_publica, os.path.join(args.outdir, 'priorizacion_PUBLICA_NUEVO.html'), d_pu)

    print('Listo. Filas:', len(filas))
    from collections import Counter
    print(Counter(f['banda'] for f in filas))


if __name__ == '__main__':
    sys.exit(main())
