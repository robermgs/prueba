r"""
Avisa de vulnerabilidades que TODAVÍA no están en overdue, pero les
quedan pocos días para entrar (por defecto, 5 días o menos hasta el día
31, que es cuando pasan a overdue según la regla de negocio confirmada).
Así se puede actuar ANTES de que salten a overdue, no solo enterarte
después.

Uso:
    python3 generar_proximos_overdue.py SA.csv SG.csv 2026-09-03 \
        --margen-dias 5 --out ..\resumenes\proximos_overdue_2026-09-03.txt
"""
import argparse
import sys
from datetime import datetime, timedelta
from collections import defaultdict

from core import cargar_datos, _dias_publicada, _overdue_bool

UMBRAL_OVERDUE_DIA = 31


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--margen-dias', type=int, default=5)
    ap.add_argument('--out', default='proximos_overdue.txt')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)

    umbral_inferior = UMBRAL_OVERDUE_DIA - args.margen_dias

    vistas = {}
    for r in filas:
        if _overdue_bool(r):
            continue  # ya está en overdue, no nos interesa aquí
        dp = _dias_publicada(r)
        if dp is None or dp < umbral_inferior:
            continue
        clave = (r['norm'], r['QID'])
        vistas.setdefault(clave, {
            'norm': r['norm'], 'qid': r['QID'], 'title': r.get('Title', ''),
            'entidad': r.get('Entidad', ''), 'subentidad': r.get('Subentidad', ''),
            'env': r['env'], 'dias_publicada': dp,
            'dias_restantes': UMBRAL_OVERDUE_DIA - dp,
        })

    proximas = list(vistas.values())
    proximas.sort(key=lambda r: r['dias_restantes'])

    print(f'{len(proximas)} combinación(es) máquina+vulnerabilidad a {args.margen_dias} '
          f'día(s) o menos de entrar en overdue.')

    por_titulo = defaultdict(list)
    for r in proximas:
        por_titulo[(r['qid'], r['title'])].append(r)

    lineas = [
        f'PRÓXIMAS A ENTRAR EN OVERDUE · EUT Vulnes · {args.fecha}',
        f'(todavía dentro de plazo, pero a {args.margen_dias} días o menos del día {UMBRAL_OVERDUE_DIA})',
        '=' * 70,
        '',
    ]
    if not proximas:
        lineas.append('Ninguna — no hay nada a punto de entrar en overdue ahora mismo. 👍')
    else:
        fecha_hoy_dt = datetime.strptime(args.fecha, '%Y-%m-%d')
        for (qid, title), rs in sorted(por_titulo.items(), key=lambda kv: min(r['dias_restantes'] for r in kv[1])):
            dias_min = min(r['dias_restantes'] for r in rs)
            fecha_objetivo = (fecha_hoy_dt + timedelta(days=dias_min)).strftime('%d/%m/%Y')
            lineas.append(f"- {title} (QID {qid}): {len(rs)} máquina(s), la más urgente en "
                           f"{dias_min} día(s) - entra en overdue el {fecha_objetivo}")
            entidades = sorted(set(f"{r['entidad']}/{r['subentidad']}" for r in rs))
            lineas.append(f"    Entidades afectadas: {', '.join(entidades[:8])}"
                           + (f' ... (+{len(entidades)-8} más)' if len(entidades) > 8 else ''))
            lineas.append('')

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())
