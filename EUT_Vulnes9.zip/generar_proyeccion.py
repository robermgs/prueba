r"""
Proyección simple: mirando el ritmo de cambio de overdue en los últimos
días (media del cambio diario), calcula en cuántos días se llegaría a
0 overdue si esa tendencia se mantiene. Útil para comprometerte con un
plazo hacia dirección, con la letra pequeña de que es una proyección
lineal simple (no tiene en cuenta estacionalidad, despliegues puntuales,
etc.) — no una promesa.

Uso:
    python3 generar_proyeccion.py ..\historico\historico_resumen.json 2026-09-03 \
        --dias-ventana 7 --out ..\resumenes\proyeccion_overdue_2026-09-03.txt
"""
import argparse
import json
import sys


def num(n):
    return f'{n:,}'.replace(',', '.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('historico_resumen')
    ap.add_argument('fecha')
    ap.add_argument('--dias-ventana', type=int, default=7,
                     help='Cuántos días recientes usar para calcular el ritmo (por defecto 7)')
    ap.add_argument('--out', default='proyeccion_overdue.txt')
    args = ap.parse_args()

    with open(args.historico_resumen, 'r', encoding='utf-8') as f:
        hist = json.load(f)

    fechas = hist['fechas']
    overdue_serie = hist['history']['overdue']

    if len(fechas) < 2:
        with open(args.out, 'w', encoding='utf-8') as f:
            f.write('No hay histórico suficiente todavía para calcular una tendencia (hacen falta al menos 2 días).')
        print('No hay histórico suficiente.')
        return 0

    ventana = min(args.dias_ventana, len(fechas) - 1)
    valores_ventana = overdue_serie[-(ventana + 1):]
    fechas_ventana = fechas[-(ventana + 1):]

    deltas = [valores_ventana[i + 1] - valores_ventana[i] for i in range(len(valores_ventana) - 1)]
    ritmo_medio = sum(deltas) / len(deltas) if deltas else 0
    overdue_hoy = overdue_serie[-1]

    lineas = [
        f'PROYECCIÓN DE TENDENCIA · OVERDUE · EUT Vulnes · {args.fecha}',
        f'(basada en los últimos {ventana} día(s) con histórico: {fechas_ventana[0]} a {fechas_ventana[-1]})',
        '=' * 70,
        '',
        f'Overdue hoy: {num(overdue_hoy)}',
        f'Ritmo medio de cambio diario en la ventana: {ritmo_medio:+.1f} vulnerabilidades/día',
        '',
    ]

    if ritmo_medio < -0.5:
        dias_a_cero = round(overdue_hoy / abs(ritmo_medio))
        lineas.append(f'📉 Tendencia BAJANDO. A este ritmo, llegaríais a 0 overdue en '
                       f'aproximadamente {dias_a_cero} día(s).')
        lineas.append('(Proyección lineal simple — no tiene en cuenta picos, despliegues puntuales '
                       'ni cambios de volumen de trabajo. Es una referencia, no una promesa de plazo.)')
    elif ritmo_medio > 0.5:
        lineas.append(f'📈 Tendencia SUBIENDO ({ritmo_medio:+.1f}/día de media). Al ritmo actual, '
                       f'overdue seguirá creciendo, no bajando. No se puede dar una fecha de "llegar a 0".')
    else:
        lineas.append('➡️  Tendencia prácticamente ESTABLE en la ventana analizada '
                       '(ni sube ni baja de forma clara).')

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)
    print(f'Ritmo medio: {ritmo_medio:+.1f}/día')


if __name__ == '__main__':
    sys.exit(main())
