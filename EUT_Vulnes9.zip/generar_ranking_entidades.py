r"""
Genera un ranking de entidades ordenadas de peor a mejor, por dos
criterios: % de vulnerabilidades en overdue, y % de máquinas
desalineadas. Pensado para saber rápido a quién hay que presionar.

Uso:
    python3 generar_ranking_entidades.py SA.csv SG.csv 2026-09-03 \
        --out ..\resumenes\ranking_entidades_2026-09-03.txt
"""
import argparse
import sys

from core import cargar_datos, tabla_maquinas, resumen_por_entidad, overdue_por_entidad, rango_dias


def num(n):
    return f'{n:,}'.replace(',', '.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--out', default='ranking_entidades.txt')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas, fecha_informe=args.fecha)
    for m in mt:
        m['range'] = rango_dias(m['dias_sin_reportar'])

    print('Calculando desalineación y overdue por entidad...')
    resumen = {r['ent']: r for r in resumen_por_entidad(mt)}
    overdue = overdue_por_entidad(filas)

    entidades = sorted(set(resumen) | set(overdue))
    filas_out = []
    for ent in entidades:
        r = resumen.get(ent, {'total': 0, 'pct_alin': 100})
        o = overdue.get(ent, {'vulns_total': 0, 'overdue': 0})
        pct_desalin = round(100 - r['pct_alin'], 1)
        pct_overdue = round(100 * o['overdue'] / o['vulns_total'], 1) if o['vulns_total'] else 0
        filas_out.append({
            'ent': ent, 'maquinas': r['total'], 'pct_desalin': pct_desalin,
            'vulns_total': o['vulns_total'], 'overdue': o['overdue'], 'pct_overdue': pct_overdue,
        })

    por_overdue = sorted(filas_out, key=lambda x: -x['pct_overdue'])
    por_desalin = sorted(filas_out, key=lambda x: -x['pct_desalin'])

    lineas = [
        f'RANKING DE ENTIDADES · EUT Vulnes · {args.fecha}',
        '=' * 60,
        '',
        '--- Peor % de OVERDUE (de más a menos) ---',
        '',
    ]
    for f in por_overdue:
        if f['vulns_total'] == 0:
            continue
        lineas.append(f"  {f['pct_overdue']:>5.1f}%  {f['ent']:<20} "
                       f"({num(f['overdue'])} de {num(f['vulns_total'])} vulns · {num(f['maquinas'])} máquinas)")

    lineas += ['', '--- Peor % de DESALINEACIÓN (de más a menos) ---', '']
    for f in por_desalin:
        if f['maquinas'] == 0:
            continue
        lineas.append(f"  {f['pct_desalin']:>5.1f}%  {f['ent']:<20} ({num(f['maquinas'])} máquinas)")

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)
    if por_overdue:
        top = next((f for f in por_overdue if f['vulns_total'] > 0), None)
        if top:
            print(f"Peor en overdue: {top['ent']} ({top['pct_overdue']}%)")
    if por_desalin:
        top = next((f for f in por_desalin if f['maquinas'] > 0), None)
        if top:
            print(f"Peor en desalineación: {top['ent']} ({top['pct_desalin']}%)")


if __name__ == '__main__':
    sys.exit(main())
