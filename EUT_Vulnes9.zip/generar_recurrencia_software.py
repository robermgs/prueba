"""
Genera (o actualiza) dashboard_recurrencia_software.html.

OJO — aproximación: el nombre de "software" se deduce del título con una
mezcla de alias conocidos + primeras palabras (ver core.nombre_software).
El original parece tener retoques manuales que no podemos reproducir al
100%, así que algunos nombres no coincidirán exactamente.

Reutiliza el histórico por título que ya genera generar_vulnerabilidades.py
(historico_vulnerabilidades.json → titulos_hist: {titulo: {fecha: maquinas}}).

Uso:
    python3 generar_recurrencia_software.py \\
        --historico-vulns historico_vulnerabilidades.json \\
        --template dashboard_recurrencia_software.html \\
        --out dashboard_recurrencia_software_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import nombre_software


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--historico-vulns', default='historico_vulnerabilidades.json')
    ap.add_argument('--template', default='dashboard_recurrencia_software.html')
    ap.add_argument('--out', default='dashboard_recurrencia_software_NUEVO.html')
    args = ap.parse_args()

    with open(args.historico_vulns, 'r', encoding='utf-8') as f:
        hist = json.load(f)
    fechas = hist['fechas']
    titulos_hist = hist['titulos_hist']  # {titulo: {fecha: maquinas}}

    print('Agrupando títulos en "software" (aproximado)...')
    por_software = {}
    for titulo, por_fecha in titulos_hist.items():
        sw = nombre_software(titulo)
        acc = por_software.setdefault(sw, {f: 0 for f in fechas})
        for f, m in por_fecha.items():
            acc[f] = acc.get(f, 0) + m

    filas = []
    n_dias = len(fechas)
    for sw, por_fecha in por_software.items():
        valores = [por_fecha.get(f, 0) for f in fechas]
        dias_presente = sum(1 for v in valores if v > 0)
        pct = dias_presente / n_dias * 100
        presentes = [v for v in valores if v > 0]
        if not presentes:
            continue
        if pct >= 80:
            clasif = 'Crónico'
        elif pct >= 50:
            clasif = 'Frecuente'
        else:
            clasif = 'Puntual'
        primero = next((v for v in valores if v > 0), 0)
        ultimo = next((v for v in reversed(valores) if v > 0), 0)
        if ultimo > primero * 1.1:
            tendencia = '↑ Subiendo'
        elif ultimo < primero * 0.9:
            tendencia = '↓ Bajando'
        else:
            tendencia = '→ Estable'
        filas.append({
            'software': sw, 'clasif': clasif, 'dias_presente': dias_presente, 'n_dias': n_dias,
            'pct': round(pct, 0), 'media': round(sum(presentes) / len(presentes)),
            'maximo': max(presentes), 'minimo': min(presentes), 'tendencia': tendencia,
        })

    filas.sort(key=lambda r: (-r['pct'], -r['media']))

    print('Renderizando filas HTML...')
    color = {'Crónico': '#ef4444', 'Frecuente': '#f59e0b', 'Puntual': '#22c55e'}
    tendencia_color = {'↑ Subiendo': '#ef4444', '↓ Bajando': '#22c55e', '→ Estable': '#94a3b8'}
    filas_html = []
    for r in filas:
        c = color[r['clasif']]
        tc = tendencia_color[r['tendencia']]
        filas_html.append(f'''        <tr>
          <td style="font-weight:600;color:#f0f4ff">{r['software']}</td>
          <td style="text-align:center">
            <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:11px;font-weight:700;
              background:{c}22;border:1px solid {c};color:{c}">{r['clasif']}</span>
          </td>
          <td style="text-align:center;color:{c};font-weight:700">{r['dias_presente']}/{r['n_dias']}<br>
            <span style="font-size:10px;font-weight:400;color:#8899bb">({r['pct']:.0f}% días)</span></td>
          <td style="text-align:right;font-weight:700;color:#f0f4ff">{r['media']:,}</td>
          <td style="text-align:right;color:#ef4444">{r['maximo']:,}</td>
          <td style="text-align:right;color:#22c55e">{r['minimo']:,}</td>
          <td style="color:{tc};font-weight:600;text-align:center">{r['tendencia']}</td>
        </tr>''')

    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()

    content = re.sub(r'<tbody>.*?</tbody>', '<tbody>\n' + '\n'.join(filas_html) + '\n    </tbody>',
                      content, flags=re.S)

    cronicos = sum(1 for r in filas if r['clasif'] == 'Crónico')
    frecuentes = sum(1 for r in filas if r['clasif'] == 'Frecuente')
    content = re.sub(r'(<div class="val">)\d+(</div>)', rf'\g<1>{len(filas)}\g<2>', content, count=1)
    content = re.sub(r'(<div class="val red">)\d+(</div>)', rf'\g<1>{cronicos}\g<2>', content, count=1)
    content = re.sub(r'(<div class="val amber">)\d+(</div>)', rf'\g<1>{frecuentes}\g<2>', content, count=1)

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print('Software:', len(filas), '| Crónicos:', cronicos, '| Frecuentes:', frecuentes)


if __name__ == '__main__':
    sys.exit(main())
