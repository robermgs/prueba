"""
Genera (o actualiza) dashboard_resumen.html a partir de SA.csv y SG.csv.

- Mantiene un histórico persistente en historico_resumen.json (FECHAS,
  HISTORY, SUMMARY sin machines_all, PER_DATE_VULNS, PER_DATE_COMBOS).
- Calcula el día de hoy con el motor de core.py.
- Vuelca todo dentro de la plantilla HTML original (todo el CSS/JS se
  mantiene intacto; solo se reemplazan los bloques de datos).

Uso:
    python3 generar_resumen.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_resumen.html \\
        --historico historico_resumen.json \\
        --out dashboard_resumen_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import cargar_datos, tabla_maquinas, resumen_dia, vulns_del_dia, combos_unicos


def extraer_const(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\}|\[.*?\]);\r?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return json.loads(m.group(1)), m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def sembrar_historico_desde_html(template_path):
    """La primera vez que se ejecuta, extrae el histórico ya existente
    dentro del HTML de ejemplo para no perder los días previos."""
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    fechas, _ = extraer_const(content, 'FECHAS')
    history, _ = extraer_const(content, 'HISTORY')
    summary, _ = extraer_const(content, 'SUMMARY')
    per_date_vulns, _ = extraer_const(content, 'PER_DATE_VULNS')
    per_date_combos, _ = extraer_const(content, 'PER_DATE_COMBOS')

    # No guardamos machines_all de días viejos para no disparar el tamaño
    for f in summary:
        summary[f].pop('machines_all', None)

    return {
        'fechas': fechas,
        'history': history,
        'summary': summary,
        'per_date_vulns': per_date_vulns,
        'per_date_combos': per_date_combos,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha', help='Fecha del informe, formato YYYY-MM-DD')
    ap.add_argument('--template', default='dashboard_resumen.html')
    ap.add_argument('--historico', default='historico_resumen.json')
    ap.add_argument('--out', default='dashboard_resumen_NUEVO.html')
    args = ap.parse_args()

    hist = cargar_historico(args.historico)
    if hist is None:
        print(f'No hay histórico previo, lo siembro desde {args.template}...')
        hist = sembrar_historico_desde_html(args.template)

    print('Cargando CSV...')
    df = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(df, fecha_informe=args.fecha)

    # títulos y nº de máquinas del día anterior (para 'nuevo' y 'delta')
    fechas_previas = [f for f in hist['fechas'] if f < args.fecha]
    titles_previos = None
    if fechas_previas:
        fecha_ant = fechas_previas[-1]
        vulns_ant = hist['per_date_vulns'].get(fecha_ant, [])
        titles_previos = {v['qid']: v['machines'] for v in vulns_ant}

    print('Calculando vulnerabilidades del día...')
    vdia = vulns_del_dia(df, titles_previos=titles_previos)

    print('Calculando resumen del día...')
    s = resumen_dia(df, mt, args.fecha, titles_dia_anterior=set(titles_previos) if titles_previos else None,
                     vulns_dia=vdia)

    # Actualizar histórico en memoria
    if args.fecha not in hist['fechas']:
        hist['fechas'].append(args.fecha)
        hist['fechas'].sort()
        for k in ('labels', 'machines', 'vulns', 'overdue', 'no_overdue', 'titles'):
            hist['history'].setdefault(k, [])
        hist['history']['labels'] = hist['fechas']
        hist['history']['machines'].append(s['machines_total'])
        hist['history']['vulns'].append(s['vulns_total'])
        hist['history']['overdue'].append(s['overdue_total'])
        hist['history']['no_overdue'].append(s['vulns_total'] - s['overdue_total'])
        hist['history']['titles'].append(s['titles_unique'])
    else:
        idx = hist['fechas'].index(args.fecha)
        hist['history']['machines'][idx] = s['machines_total']
        hist['history']['vulns'][idx] = s['vulns_total']
        hist['history']['overdue'][idx] = s['overdue_total']
        hist['history']['no_overdue'][idx] = s['vulns_total'] - s['overdue_total']
        hist['history']['titles'][idx] = s['titles_unique']

    # SUMMARY del día actual SÍ lleva machines_all (es el que se pinta con detalle)
    hist['summary'][args.fecha] = s
    hist['per_date_vulns'][args.fecha] = vdia
    hist['per_date_combos'][args.fecha] = combos_unicos(mt)

    print('Guardando histórico...')
    # Al guardar el histórico en disco, no persistimos machines_all de HOY
    # (se recalcula siempre desde los CSV); así el JSON no crece sin control.
    hist_a_guardar = json.loads(json.dumps(hist))
    hist_a_guardar['summary'][args.fecha] = {k: v for k, v in s.items() if k != 'machines_all'}
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist_a_guardar, f, ensure_ascii=False)

    print('Generando HTML final...')
    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()

    for name, value in [
        ('FECHAS', hist['fechas']),
        ('HISTORY', hist['history']),
        ('SUMMARY', hist['summary']),
        ('PER_DATE_VULNS', hist['per_date_vulns']),
        ('PER_DATE_COMBOS', hist['per_date_combos']),
    ]:
        _, span = extraer_const(content, name)
        nuevo_json = json.dumps(value, ensure_ascii=False)
        content = content[:span[0]] + nuevo_json + content[span[1]:]
        # recalcular posiciones tras cada sustitución
        content = content  # (re-extraído en la siguiente iteración por regex)

    # LAST_FECHA también se actualiza
    content = re.sub(r"const LAST_FECHA\s*=\s*'[^']*';",
                      f"const LAST_FECHA = '{args.fecha}';", content)

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print(f"Máquinas: {s['machines_total']} | Vulns: {s['vulns_total']} | Overdue: {s['overdue_total']} | Títulos: {s['titles_unique']}")


if __name__ == '__main__':
    sys.exit(main())
