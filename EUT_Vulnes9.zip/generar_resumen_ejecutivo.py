r"""
Genera un resumen ejecutivo del día a partir de historico_resumen.json
(el que ya produce generar_resumen.py). Saca dos ficheros de texto:

  - resumen_ejecutivo_<fecha>.txt   -> versión detallada, para leer/archivar
  - evolutivo_teams_<fecha>.txt     -> versión corta con emojis, lista para
                                       copiar y pegar en el grupo de Teams

Debe ejecutarse DESPUÉS de generar_resumen.py (para esa misma fecha), ya
que reutiliza su histórico.

Uso:
    python3 generar_resumen_ejecutivo.py 2026-08-30 \
        --historico ..\historico\historico_resumen.json \
        --outdir ..\resumenes
"""
import argparse
import json
import os
import sys


def flecha(delta):
    if delta > 0:
        return f'⬆ +{delta:,}'.replace(',', '.')
    if delta < 0:
        return f'⬇ {delta:,}'.replace(',', '.')
    return '➡ estable'


def flecha_txt(delta):
    if delta > 0:
        return f'subió +{delta:,}'.replace(',', '.')
    if delta < 0:
        return f'bajó {delta:,}'.replace(',', '.')
    return 'se mantuvo estable'


def num(n):
    return f'{n:,}'.replace(',', '.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('fecha')
    ap.add_argument('--historico', default='historico_resumen.json')
    ap.add_argument('--outdir', default='.')
    args = ap.parse_args()

    with open(args.historico, 'r', encoding='utf-8') as f:
        hist = json.load(f)

    fechas = sorted(f for f in hist['fechas'] if f <= args.fecha)
    if not fechas or fechas[-1] != args.fecha:
        print(f'Aviso: no hay datos para {args.fecha} en {args.historico}.')
        return 1
    fecha_hoy = fechas[-1]
    fecha_ayer = fechas[-2] if len(fechas) > 1 else None

    s_hoy = hist['summary'][fecha_hoy]
    s_ayer = hist['summary'].get(fecha_ayer) if fecha_ayer else None

    machines_hoy = s_hoy['machines_total']
    vulns_hoy = s_hoy['vulns_total']
    overdue_hoy = s_hoy['overdue_total']
    desalin_pct_hoy = round(100 * s_hoy['alignment_desalin_global'] / s_hoy['alignment_total_global'], 1) \
        if s_hoy['alignment_total_global'] else 0
    overdue_pct_hoy = round(100 * overdue_hoy / vulns_hoy, 1) if vulns_hoy else 0
    nuevas = s_hoy.get('new_titles', [])

    d_machines = d_vulns = d_overdue = d_desalin_pct = None
    anomalias = []
    UMBRAL_ANOMALIA = 15
    if s_ayer:
        d_machines = machines_hoy - s_ayer['machines_total']
        d_vulns = vulns_hoy - s_ayer['vulns_total']
        d_overdue = overdue_hoy - s_ayer['overdue_total']
        desalin_pct_ayer = round(100 * s_ayer['alignment_desalin_global'] / s_ayer['alignment_total_global'], 1) \
            if s_ayer['alignment_total_global'] else 0
        d_desalin_pct = round(desalin_pct_hoy - desalin_pct_ayer, 1)

        for etiqueta, hoy_val, ayer_val in [
            ('Máquinas vulnerables', machines_hoy, s_ayer['machines_total']),
            ('Vulnerabilidades totales', vulns_hoy, s_ayer['vulns_total']),
            ('En overdue', overdue_hoy, s_ayer['overdue_total']),
        ]:
            if ayer_val:
                pct = round((hoy_val - ayer_val) / ayer_val * 100, 1)
                if abs(pct) >= UMBRAL_ANOMALIA:
                    anomalias.append((etiqueta, ayer_val, hoy_val, pct))

    top_nuevas = sorted(nuevas, key=lambda v: -v['machines'])[:3]
    top_maquina = s_hoy['top_machines'][0] if s_hoy.get('top_machines') else None

    # ------------------------------------------------------------------
    # Puntos clave (3-5), priorizados
    # ------------------------------------------------------------------
    puntos = []
    if d_overdue is not None and d_overdue > 0:
        puntos.append(f'Las vulnerabilidades en overdue han subido en {num(d_overdue)} respecto a ayer '
                       f'({num(overdue_hoy)} en total, el {overdue_pct_hoy}% del total).')
    elif overdue_pct_hoy >= 35:
        puntos.append(f'El overdue sigue alto: {num(overdue_hoy)} vulnerabilidades ({overdue_pct_hoy}% del total).')

    if nuevas:
        titulos = '; '.join(f"«{v['title']}» ({num(v['machines'])} máquinas)" for v in top_nuevas)
        puntos.append(f'{len(nuevas)} vulnerabilidad(es) nueva(s) hoy: {titulos}.')

    if d_machines is not None and d_machines != 0:
        puntos.append(f'Máquinas vulnerables: {flecha_txt(d_machines)} respecto a ayer ({num(machines_hoy)} en total).')

    if d_desalin_pct is not None and abs(d_desalin_pct) >= 0.5:
        puntos.append(f'El % de máquinas desalineadas ha {"subido" if d_desalin_pct > 0 else "bajado"} '
                       f'{abs(d_desalin_pct)} puntos, hasta el {desalin_pct_hoy}%.')

    if top_maquina and top_maquina['count'] >= 50:
        puntos.append(f"La máquina más afectada es {top_maquina['machine']} "
                       f"({top_maquina['ent']}/{top_maquina['sub']}) con {top_maquina['count']} vulnerabilidades.")

    if not puntos:
        puntos.append('Sin cambios relevantes respecto a ayer.')
    puntos = puntos[:5]

    # ------------------------------------------------------------------
    # Fichero detallado
    # ------------------------------------------------------------------
    lineas = [
        f'RESUMEN EJECUTIVO · EUT Vulnes · {fecha_hoy}',
        '=' * 50,
        '',
    ]
    if anomalias:
        lineas.append('⚠️  AVISO: CAMBIOS ANÓMALOS RESPECTO A AYER (>= %d%%)' % UMBRAL_ANOMALIA)
        for etiqueta, antes, ahora, pct in anomalias:
            signo = '+' if pct > 0 else ''
            lineas.append(f'  - {etiqueta}: {num(antes)} -> {num(ahora)}  ({signo}{pct}%)')
        lineas.append('  Puede ser normal (despliegues masivos, etc.) o un problema con el export.')
        lineas.append('  Conviene confirmarlo antes de dar el día por bueno.')
        lineas.append('')
    lineas.append('Lo más importante de hoy:')
    for p in puntos:
        lineas.append(f'  - {p}')
    lineas += [
        '',
        'Cifras del día:',
        f'  Máquinas vulnerables:      {num(machines_hoy)}' + (f'  ({flecha(d_machines)})' if d_machines is not None else ''),
        f'  Vulnerabilidades totales:  {num(vulns_hoy)}' + (f'  ({flecha(d_vulns)})' if d_vulns is not None else ''),
        f'  En overdue:                {num(overdue_hoy)} ({overdue_pct_hoy}%)' + (f'  ({flecha(d_overdue)})' if d_overdue is not None else ''),
        f'  % Desalineadas:            {desalin_pct_hoy}%' + (f'  ({d_desalin_pct:+.1f} pts)' if d_desalin_pct is not None else ''),
        f'  Títulos únicos:            {num(s_hoy["titles_unique"])}',
        '',
    ]

    top10 = sorted(s_hoy.get('top_machines', []), key=lambda m: -m['count'])[:10]
    if top10:
        lineas.append('Top 10 máquinas con más vulnerabilidades:')
        for i, m in enumerate(top10, 1):
            lineas.append(f"  {i:>2}. {m['machine']:<20} {m['ent']}/{m['sub']:<20} "
                           f"{num(m['count'])} vulns · cruce: {m['cruce']}")
        lineas.append('')

    if fecha_ayer:
        lineas.append(f'(comparado con {fecha_ayer})')
    lineas.append('')

    os.makedirs(args.outdir, exist_ok=True)
    path_detallado = os.path.join(args.outdir, f'resumen_ejecutivo_{fecha_hoy}.txt')
    with open(path_detallado, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    # ------------------------------------------------------------------
    # Versión corta para Teams
    # ------------------------------------------------------------------
    teams = [
        f'📊 EUT Vulnes · {fecha_hoy}',
    ]
    if anomalias:
        teams.append('⚠️ CAMBIO ANÓMALO respecto a ayer, revisar antes de dar el día por bueno:')
        for etiqueta, antes, ahora, pct in anomalias:
            signo = '+' if pct > 0 else ''
            teams.append(f'   {etiqueta}: {signo}{pct}%')
    teams += [
        f'🖥️ Máquinas vulnerables: {num(machines_hoy)}' + (f' ({flecha(d_machines)})' if d_machines is not None else ''),
        f'🛡️ Vulnerabilidades totales: {num(vulns_hoy)}' + (f' ({flecha(d_vulns)})' if d_vulns is not None else ''),
        f'⏰ En overdue: {num(overdue_hoy)} · {overdue_pct_hoy}%' + (f' ({flecha(d_overdue)})' if d_overdue is not None else ''),
        f'🔀 Desalineadas: {desalin_pct_hoy}%' + (f' ({d_desalin_pct:+.1f} pts)' if d_desalin_pct is not None else ''),
    ]
    if nuevas:
        teams.append(f'🆕 {len(nuevas)} vulnerabilidad(es) nueva(s) hoy')
    if top10:
        teams.append('🏆 Top 3 máquinas con más vulnerabilidades:')
        for i, m in enumerate(top10[:3], 1):
            teams.append(f"   {i}. {m['machine']} ({m['ent']}/{m['sub']}) · {num(m['count'])} vulns")
    path_teams = os.path.join(args.outdir, f'evolutivo_teams_{fecha_hoy}.txt')
    with open(path_teams, 'w', encoding='utf-8') as f:
        f.write('\n'.join(teams))

    print(f'Listo:\n  {path_detallado}\n  {path_teams}')
    print()
    print('--- Vista previa (Teams) ---')
    print('\n'.join(teams))


if __name__ == '__main__':
    sys.exit(main())
