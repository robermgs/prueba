"""
Genera (o actualiza) dashboard_resumen_entidades.html a partir de SA.csv y SG.csv.
Panel pequeño y sin histórico: solo la foto de hoy (SNAPSHOT, SUMMARY, DETAIL).

Uso:
    python3 generar_resumen_entidades.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_resumen_entidades.html \\
        --out dashboard_resumen_entidades_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import cargar_datos, tabla_maquinas, rango_dias, resumen_por_entidad, detalle_por_entidad


def extraer_const_span(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*("[^"]*"|\{.*?\}|\[.*?\]);.*?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return m.span(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_resumen_entidades.html')
    ap.add_argument('--out', default='dashboard_resumen_entidades_NUEVO.html')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(filas, fecha_informe=args.fecha)
    for r in mt:
        r['range'] = rango_dias(r['dias_sin_reportar'])

    print('Calculando resumen y detalle por entidad...')
    summary = resumen_por_entidad(mt)
    detail = detalle_por_entidad(filas)

    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()

    for name, value in [
        ('SNAPSHOT', args.fecha),
        ('SUMMARY', summary),
        ('DETAIL', detail),
    ]:
        span = extraer_const_span(content, name)
        content = content[:span[0]] + json.dumps(value, ensure_ascii=False) + content[span[1]:]

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print('Entidades:', len(summary))


if __name__ == '__main__':
    sys.exit(main())
