r"""
Genera el informe de "fixed" del día CRUZANDO el CSV de hoy contra una
"foto" (snapshot) guardada del día anterior — NO usa el campo Status del
CSV, porque Sergio confirmó que ese campo no es fiable para esto (una
vulnerabilidad puede aparecer "FIXED" simplemente porque la máquina dejó
de reportar a Qualys, no porque se haya arreglado de verdad).

Criterio: si una combinación (máquina, QID) estaba en el snapshot de ayer
y hoy ya NO aparece en el CSV, se considera "desaparecida" — puede ser un
fix real o que la máquina se dio de baja; el propio Sergio no distingue
entre ambos casos tampoco.

Cada ejecución:
  1. Compara hoy vs. el snapshot guardado (si existe) -> informe de hoy.
  2. Guarda el snapshot de HOY para poder compararlo mañana.

Uso:
    python3 generar_resumen_fixed.py SA.csv SG.csv 2026-09-02 \
        --snapshot ..\historico\snapshot_vulnes.json \
        --out-maquinas ..\resumenes\resumen_maquinas_fixed_2026-09-02.csv \
        --out-vulnes ..\resumenes\resumen_vulnes_fixed_2026-09-02.csv
"""
import argparse
import csv
import json
import sys
from collections import defaultdict

from core import cargar_datos, _dias_publicada, _overdue_bool


def cargar_snapshot(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


UMBRAL_SLA_DIAS = 30


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--snapshot', default='snapshot_vulnes.json')
    ap.add_argument('--out-maquinas', default='resumen_maquinas_fixed.csv')
    ap.add_argument('--out-vulnes', default='resumen_vulnes_fixed.csv')
    ap.add_argument('--out-transiciones', default='transiciones_overdue.csv')
    args = ap.parse_args()

    print('Cargando CSV de hoy...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)

    hoy_detalle = {}  # "norm|QID" -> {entidad, subentidad, env, title, dias_publicada, overdue}
    for r in filas:
        clave = f"{r['norm']}|{r['QID']}"
        hoy_detalle.setdefault(clave, {
            'entidad': r.get('Entidad', ''), 'subentidad': r.get('Subentidad', ''),
            'env': r['env'], 'title': r.get('Title', ''), 'norm': r['norm'], 'qid': r['QID'],
            'dias_publicada': _dias_publicada(r), 'overdue': _overdue_bool(r),
        })

    snap = cargar_snapshot(args.snapshot)

    if snap is None:
        print('Aviso: no hay snapshot de un día anterior — es la primera vez que se '
              'ejecuta esto, así que hoy no se puede calcular ningún "fixed" todavía. '
              'A partir de mañana ya funcionará.')
        desaparecidas = []
    else:
        claves_ayer = set(snap['detalle'].keys())
        claves_hoy = set(hoy_detalle.keys())
        claves_desaparecidas = claves_ayer - claves_hoy
        desaparecidas = [snap['detalle'][c] for c in claves_desaparecidas]
        print(f'{len(desaparecidas)} combinación(es) máquina+vulnerabilidad de '
              f'{snap["fecha"]} que hoy ya no aparecen (posible fix, o baja de Qualys).')

    for r in desaparecidas:
        dp = r.get('dias_publicada')
        r['cumplio_sla'] = ('Sí' if dp is not None and dp <= UMBRAL_SLA_DIAS
                             else ('No' if dp is not None else ''))

    # --- Entradas y salidas de overdue (comparando hoy contra el snapshot de ayer) ---
    transiciones = []
    if snap is not None:
        detalle_ayer = snap['detalle']
        claves_comunes = set(hoy_detalle.keys()) & set(detalle_ayer.keys())
        for c in claves_comunes:
            overdue_hoy = hoy_detalle[c]['overdue']
            overdue_ayer = detalle_ayer[c].get('overdue', False)
            if overdue_hoy and not overdue_ayer:
                transiciones.append({'tipo': 'Entrada', **hoy_detalle[c]})
            elif overdue_ayer and not overdue_hoy:
                transiciones.append({'tipo': 'Salida (sigue activa, ya no overdue)', **hoy_detalle[c]})
        # Las que desaparecieron (fixed) estando en overdue también son una "salida"
        for r in desaparecidas:
            if r.get('overdue'):
                transiciones.append({'tipo': 'Salida (arreglada)', **r})
        transiciones.sort(key=lambda r: (r['tipo'], r['entidad'], r['subentidad'], r['norm']))
        n_entradas = sum(1 for t in transiciones if t['tipo'] == 'Entrada')
        n_salidas = len(transiciones) - n_entradas
        print(f'{n_entradas} vulnerabilidad(es) han ENTRADO en overdue hoy | '
              f'{n_salidas} han SALIDO de overdue hoy (arregladas o ya no overdue)')

    with open(args.out_transiciones, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['Fecha', 'Tipo', 'Entorno', 'Entidad', 'Subentidad', 'Netbios', 'QID', 'Titulo'])
        for t in transiciones:
            w.writerow([args.fecha, t['tipo'], t['env'], t['entidad'], t['subentidad'],
                        t['norm'], t['qid'], t['title']])
    print('Listo:', args.out_transiciones)

    desaparecidas.sort(key=lambda r: (r['entidad'], r['subentidad'], r['norm']))
    total_por_qid = defaultdict(int)
    for r in desaparecidas:
        total_por_qid[r['qid']] += 1

    with open(args.out_maquinas, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['Fecha', 'Entorno', 'Entidad', 'Subentidad', 'Netbios', 'QID', 'Titulo',
                    'Total_Maquinas_Desaparecidas_Esta_Vulne', 'Dias_Publicada_Al_Desaparecer',
                    'Cumplio_SLA_30_dias'])
        for r in desaparecidas:
            w.writerow([args.fecha, r['env'], r['entidad'], r['subentidad'], r['norm'],
                        r['qid'], r['title'], total_por_qid[r['qid']],
                        r.get('dias_publicada', ''), r['cumplio_sla']])
    print('Listo:', args.out_maquinas)

    por_vuln = defaultdict(list)
    for r in desaparecidas:
        por_vuln[(r['qid'], r['title'])].append(r)
    filas_vuln = sorted(por_vuln.items(), key=lambda kv: -len(kv[1]))

    with open(args.out_vulnes, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f, delimiter=';')
        w.writerow(['Fecha', 'QID', 'Titulo', 'Maquinas_Desaparecidas'])
        for (qid, title), rs in filas_vuln:
            w.writerow([args.fecha, qid, title, len(rs)])
    print('Listo:', args.out_vulnes)

    print('Guardando snapshot de hoy para la comparación de mañana...')
    with open(args.snapshot, 'w', encoding='utf-8') as f:
        json.dump({'fecha': args.fecha, 'detalle': hoy_detalle}, f, ensure_ascii=False)


if __name__ == '__main__':
    sys.exit(main())
