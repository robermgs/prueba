r"""
Genera una tabla HTML con las vulnerabilidades que tienen seguimiento
manual en Estado_vulnes_1.csv (QID, título, máquinas, overdue, días de
vida, delta vs. ayer, estado) — pensada para abrir en el navegador,
seleccionar todo (Ctrl+A), copiar (Ctrl+C) y pegar directamente en Teams
manteniendo el formato de tabla.

Uso:
    python3 generar_tabla_teams.py SA.csv SG.csv Estado_vulnes_1.csv 2026-08-30 \
        --historico-vulns ..\historico\historico_vulnerabilidades.json \
        --out ..\resumenes\tabla_teams_2026-08-30.html
"""
import argparse
import json
import sys

from core import cargar_datos, cargar_estados, _overdue_bool, _dias_publicada


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('estados_csv')
    ap.add_argument('fecha')
    ap.add_argument('--historico-vulns', default='historico_vulnerabilidades.json')
    ap.add_argument('--out', default='tabla_teams.html')
    args = ap.parse_args()

    print('Cargando CSV...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    estados = cargar_estados(args.estados_csv)

    titulos_hist = {}
    try:
        with open(args.historico_vulns, 'r', encoding='utf-8') as f:
            h = json.load(f)
        for f_, vulns in h.get('per_date_vulns', {}).items():
            if f_ < args.fecha:
                for v in vulns:
                    titulos_hist.setdefault(v['title'], {})[f_] = v['machines']
    except FileNotFoundError:
        pass

    por_titulo = {}
    for r in filas:
        por_titulo.setdefault(r['Title'], []).append(r)

    filas_out = []
    for title, estado in estados.items():
        rs = por_titulo.get(title)
        if not rs:
            continue  # ya no aparece en el CSV de hoy (resuelta / fuera de alcance)
        vistas = {}
        for r in rs:
            vistas.setdefault(r['norm'], r)
        rs_u = list(vistas.values())
        machines = len(rs_u)
        overdue = any(_overdue_bool(r) for r in rs_u)
        dias_pub = [d for d in (_dias_publicada(r) for r in rs) if d is not None]
        dias_vida = max(dias_pub) if dias_pub else None
        qid = rs[0]['QID']

        fechas_prev = sorted(f for f in titulos_hist.get(title, {}) if f < args.fecha)
        delta_txt = 'Nueva'
        if fechas_prev:
            machines_ayer = titulos_hist[title][fechas_prev[-1]]
            d = machines - machines_ayer
            delta_txt = '=' if d == 0 else (f'+{d}' if d > 0 else str(d))

        filas_out.append({
            'qid': qid, 'title': title, 'machines': machines, 'overdue': overdue,
            'dias_vida': dias_vida, 'delta': delta_txt, 'estado': estado,
        })

    filas_out.sort(key=lambda r: -r['machines'])

    print(f'{len(filas_out)} vulnerabilidad(es) con seguimiento y presentes hoy.')

    color_delta = lambda d: '#22c55e' if d.startswith('-') else ('#ef4444' if d.startswith('+') else '#94a3b8')

    filas_html = []
    for r in filas_out:
        filas_html.append(f'''<tr>
<td style="padding:8px;border:1px solid #333">{r['qid']}</td>
<td style="padding:8px;border:1px solid #333">{r['title']}</td>
<td style="padding:8px;border:1px solid #333;text-align:right">{r['machines']}</td>
<td style="padding:8px;border:1px solid #333;text-align:center">{'Sí' if r['overdue'] else 'No'}</td>
<td style="padding:8px;border:1px solid #333;text-align:right">{r['dias_vida'] if r['dias_vida'] is not None else '-'}</td>
<td style="padding:8px;border:1px solid #333;text-align:center;color:{color_delta(r['delta'])};font-weight:bold">{r['delta']}</td>
<td style="padding:8px;border:1px solid #333;font-weight:bold">{r['estado']}</td>
</tr>''')

    html = f'''<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><title>Vulnerabilidades · {args.fecha}</title></head>
<body style="background:#111;color:#eee;font-family:Segoe UI,Arial,sans-serif">
<h2>Vulnerabilidades ({len(filas_out)}) · {args.fecha}</h2>
<table style="border-collapse:collapse;width:100%;font-size:14px">
<tr style="background:#1e293b">
<th style="padding:8px;border:1px solid #333">QID</th>
<th style="padding:8px;border:1px solid #333">Vulnerabilidad</th>
<th style="padding:8px;border:1px solid #333">Máquinas</th>
<th style="padding:8px;border:1px solid #333">Overdue</th>
<th style="padding:8px;border:1px solid #333">Días vida</th>
<th style="padding:8px;border:1px solid #333">Delta</th>
<th style="padding:8px;border:1px solid #333">Estado</th>
</tr>
{"".join(filas_html)}
</table>
<p style="color:#888;font-size:12px">Selecciona toda la tabla (Ctrl+A dentro de ella) y cópiala (Ctrl+C) para pegarla en Teams.</p>
</body></html>'''

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(html)
    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())
