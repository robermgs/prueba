r"""
Avisa de vulnerabilidades en Estado_vulnes_1.csv cuyo seguimiento lleva
muchos días sin tocarse (nadie ha añadido una entrada nueva al
Historial), para que no se queden estancadas sin que nadie se entere.

Mira la ÚLTIMA fecha [DD/MM/YYYY HH:MM] que aparezca en el campo
Historial de cada fila, y si han pasado más de --umbral-dias desde
entonces (por defecto 7), la lista como "olvidada".

Uso:
    python3 generar_tickets_olvidados.py Estado_vulnes_1.csv 2026-09-03 \
        --umbral-dias 7 --out ..\resumenes\tickets_olvidados_2026-09-03.txt
"""
import argparse
import csv
import sys
from datetime import datetime

from core import ultima_fecha_estado


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('estados_csv')
    ap.add_argument('fecha')
    ap.add_argument('--umbral-dias', type=int, default=7)
    ap.add_argument('--out', default='tickets_olvidados.txt')
    args = ap.parse_args()

    fecha_hoy = datetime.strptime(args.fecha, '%Y-%m-%d')

    with open(args.estados_csv, 'r', encoding='utf-8-sig', newline='') as f:
        filas = list(csv.DictReader(f))

    olvidadas = []
    sin_fecha = []
    for r in filas:
        ult = ultima_fecha_estado(r.get("Historial", ""), r.get("Estado", ""))
        if ult is None:
            sin_fecha.append(r)
            continue
        dias = (fecha_hoy - ult).days
        if dias >= args.umbral_dias:
            olvidadas.append((dias, ult, r))

    olvidadas.sort(key=lambda x: -x[0])

    print(f'{len(filas)} vulnerabilidad(es) en seguimiento | '
          f'{len(olvidadas)} sin actualizar hace >= {args.umbral_dias} días | '
          f'{len(sin_fecha)} sin ninguna fecha reconocible en el Historial')

    lineas = [
        f'TICKETS OLVIDADOS · EUT Vulnes · {args.fecha}',
        f'(sin actualizar desde hace {args.umbral_dias} días o más)',
        '=' * 60,
        '',
    ]
    if not olvidadas:
        lineas.append('Ninguno — todo el seguimiento está al día. 👍')
    for dias, ult, r in olvidadas:
        lineas.append(f"- [{dias} días sin tocar, última: {ult.strftime('%d/%m/%Y')}] "
                       f"{r['Title']}")
        lineas.append(f"    Prioridad: {r.get('Prioridad','')} · "
                       f"Responsable: {r.get('Responsable','') or '(sin asignar)'}")
        lineas.append(f"    Estado actual: {r.get('Estado','')}")
        lineas.append('')

    if sin_fecha:
        lineas.append('-' * 60)
        lineas.append(f'{len(sin_fecha)} fila(s) con un Historial sin fecha reconocible '
                       f'(revisar formato a mano):')
        for r in sin_fecha:
            lineas.append(f"  - {r['Title']}")

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())
