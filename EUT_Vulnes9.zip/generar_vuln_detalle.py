"""
Genera (o actualiza) dashboard_vuln_detalle.html a partir de SA.csv y SG.csv.
Comparte el mismo VULN_DETAIL que dashboard_vulnerabilidades.html.

Uso:
    python3 generar_vuln_detalle.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_vuln_detalle.html \\
        --historico historico_vuln_detalle.json \\
        --out dashboard_vuln_detalle_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import cargar_datos, tabla_maquinas, vuln_detail_por_titulo


def extraer_const_span(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\}|\[.*?\]);\r?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def sembrar_historico_desde_html(template_path):
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    span_f = extraer_const_span(content, 'FECHAS')
    fechas = json.loads(content[span_f[0]:span_f[1]])
    titulos_hist = {}
    # No tenemos histórico por título más allá de lo que ya trae 'history'
    # dentro de cada entrada del VULN_DETAIL de la propia plantilla
    span_v = extraer_const_span(content, 'VULN_DETAIL')
    vd = json.loads(content[span_v[0]:span_v[1]])
    for title, det in vd.items():
        titulos_hist[title] = dict(zip(fechas, det.get('history', [])))
    return {'fechas': fechas, 'titulos_hist': titulos_hist}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_vuln_detalle.html')
    ap.add_argument('--historico', default='historico_vuln_detalle.json')
    ap.add_argument('--out', default='dashboard_vuln_detalle_NUEVO.html')
    args = ap.parse_args()

    hist = cargar_historico(args.historico)
    if hist is None:
        print(f'No hay histórico previo, lo siembro desde {args.template}...')
        hist = sembrar_historico_desde_html(args.template)

    print('Cargando CSV...')
    df = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(df, fecha_informe=args.fecha)

    print('Calculando VULN_DETAIL...')
    vdet = vuln_detail_por_titulo(df, mt, args.fecha)

    for title, det in vdet.items():
        hist['titulos_hist'].setdefault(title, {})[args.fecha] = det['machines_count']
        hist.setdefault('titulos_hist_brutas', {}).setdefault(title, {})[args.fecha] = det['detecciones_brutas']
    if args.fecha not in hist['fechas']:
        hist['fechas'].append(args.fecha)
        hist['fechas'].sort()
    for title, det in vdet.items():
        th = hist['titulos_hist'].get(title, {})
        det['history'] = [th.get(f, 0) for f in hist['fechas']]

        thb = hist['titulos_hist_brutas'].get(title, {})
        fechas_previas = sorted(f for f in thb if f < args.fecha)
        if fechas_previas:
            det['variacion_brutas'] = det['detecciones_brutas'] - thb[fechas_previas[-1]]

    print('Guardando histórico...')
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist, f, ensure_ascii=False)

    print('Generando HTML final...')
    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()
    for name, value in [('FECHAS', hist['fechas']), ('VULN_DETAIL', vdet)]:
        span = extraer_const_span(content, name)
        content = content[:span[0]] + json.dumps(value, ensure_ascii=False) + content[span[1]:]
    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print('Titulos:', len(vdet))


if __name__ == '__main__':
    sys.exit(main())
