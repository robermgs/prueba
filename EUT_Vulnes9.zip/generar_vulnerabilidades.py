"""
Genera (o actualiza) dashboard_vulnerabilidades.html a partir de SA.csv y SG.csv.

A diferencia de dashboard_resumen.html, aquí los datos se agrupan por
TÍTULO de vulnerabilidad (no por QID), y hay dos bloques nuevos:
  - VULN_DETAIL: detalle completo por máquina de cada título (solo del
    día actual, con el historial de nº de máquinas afectadas por título).
  - BROWSER_HISTORY: nº de máquinas únicas afectadas por vulnerabilidades
    de Chrome / Edge a lo largo del tiempo.

Uso:
    python3 generar_vulnerabilidades.py SA.csv SG.csv 2026-08-26 \\
        --template dashboard_vulnerabilidades.html \\
        --historico historico_vulnerabilidades.json \\
        --out dashboard_vulnerabilidades_NUEVO.html
"""
import argparse
import json
import re
import sys

from core import (cargar_datos, tabla_maquinas, resumen_dia,
                   vulns_del_dia_por_titulo, combos_unicos,
                   vuln_detail_por_titulo, conteo_navegador)


def extraer_const(content, name):
    m = re.search(r'const ' + name + r'\s*=\s*(\{.*?\}|\[.*?\]);\r?\n', content)
    if not m:
        raise ValueError(f'No se encontró la constante {name} en la plantilla')
    return json.loads(m.group(1)), m.span(1)


def cargar_historico(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None


def sembrar_historico_desde_html(template_path):
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    fechas, _ = extraer_const(content, 'FECHAS')
    history, _ = extraer_const(content, 'HISTORY')
    summary, _ = extraer_const(content, 'SUMMARY')
    per_date_vulns, _ = extraer_const(content, 'PER_DATE_VULNS')
    per_date_combos, _ = extraer_const(content, 'PER_DATE_COMBOS')
    browser_history, _ = extraer_const(content, 'BROWSER_HISTORY')

    for f in summary:
        summary[f].pop('machines_all', None)

    # historial por título (para poder rellenar VULN_DETAIL[titulo]['history']
    # en el futuro): {titulo: {fecha: machines}}
    titulos_hist = {}
    for f, vulns in per_date_vulns.items():
        for v in vulns:
            titulos_hist.setdefault(v['title'], {})[f] = v['machines']

    return {
        'fechas': fechas,
        'history': history,
        'summary': summary,
        'per_date_vulns': per_date_vulns,
        'per_date_combos': per_date_combos,
        'browser_history': browser_history,
        'titulos_hist': titulos_hist,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('fecha')
    ap.add_argument('--template', default='dashboard_vulnerabilidades.html')
    ap.add_argument('--historico', default='historico_vulnerabilidades.json')
    ap.add_argument('--out', default='dashboard_vulnerabilidades_NUEVO.html')
    args = ap.parse_args()

    hist = cargar_historico(args.historico)
    if hist is None:
        print(f'No hay histórico previo, lo siembro desde {args.template}...')
        hist = sembrar_historico_desde_html(args.template)

    print('Cargando CSV...')
    df = cargar_datos(args.sa_csv, args.sg_csv)
    mt = tabla_maquinas(df, fecha_informe=args.fecha)

    fechas_previas = [f for f in hist['fechas'] if f < args.fecha]
    titles_previos = None
    if fechas_previas:
        fecha_ant = fechas_previas[-1]
        vulns_ant = hist['per_date_vulns'].get(fecha_ant, [])
        titles_previos = {v['title']: v['machines'] for v in vulns_ant}

    print('Calculando vulnerabilidades del día (por título)...')
    vdia = vulns_del_dia_por_titulo(df, titles_previos=titles_previos)

    print('Calculando resumen del día...')
    s = resumen_dia(df, mt, args.fecha,
                     titles_dia_anterior=set(titles_previos) if titles_previos else None,
                     vulns_dia=vdia)
    # en este panel titles_unique cuenta títulos, no QIDs
    s['titles_unique'] = len(vdia)

    print('Calculando VULN_DETAIL...')
    vdet = vuln_detail_por_titulo(df, mt, args.fecha)

    # actualizar historial por título y rellenar 'history' de cada entrada
    for title, det in vdet.items():
        hist['titulos_hist'].setdefault(title, {})[args.fecha] = det['machines_count']
        hist.setdefault('titulos_hist_brutas', {}).setdefault(title, {})[args.fecha] = det['detecciones_brutas']
    fechas_ordenadas = sorted(set(hist['fechas']) | {args.fecha})
    for title, det in vdet.items():
        th = hist['titulos_hist'].get(title, {})
        det['history'] = [th.get(f, 0) for f in fechas_ordenadas]

        thb = hist['titulos_hist_brutas'].get(title, {})
        fechas_previas = sorted(f for f in thb if f < args.fecha)
        if fechas_previas:
            det['variacion_brutas'] = det['detecciones_brutas'] - thb[fechas_previas[-1]]

    # Chrome / Edge: recalculamos hoy con datos reales; los días previos se
    # mantienen tal cual venían en el HTML original (no tenemos los CSV viejos)
    chrome_hoy = conteo_navegador(vdet, 'chrome')
    edge_hoy = conteo_navegador(vdet, 'edge based on chromium')

    if args.fecha not in hist['fechas']:
        hist['fechas'].append(args.fecha)
        hist['fechas'].sort()
        for k in ('labels', 'machines', 'vulns', 'overdue', 'no_overdue', 'titles'):
            hist['history'].setdefault(k, [])
        hist['history']['labels'] = hist['fechas']
        hist['history']['machines'].append(s['machines_total'])
        hist['history']['vulns'].append(s['vulns_total'])
        hist['history']['overdue'].append(s['overdue_total'])
        hist['history']['no_overdue'].append(s['vulns_total'] - s['overdue_total'])
        hist['history']['titles'].append(s['titles_unique'])
        for nombre, valor in (('Chrome', chrome_hoy), ('Edge', edge_hoy)):
            hist['browser_history'].setdefault(nombre, [0] * (len(hist['fechas']) - 1))
            hist['browser_history'][nombre].append(valor)
    else:
        idx = hist['fechas'].index(args.fecha)
        hist['history']['machines'][idx] = s['machines_total']
        hist['history']['vulns'][idx] = s['vulns_total']
        hist['history']['overdue'][idx] = s['overdue_total']
        hist['history']['no_overdue'][idx] = s['vulns_total'] - s['overdue_total']
        hist['history']['titles'][idx] = s['titles_unique']
        for nombre, valor in (('Chrome', chrome_hoy), ('Edge', edge_hoy)):
            hist['browser_history'].setdefault(nombre, [0] * len(hist['fechas']))
            hist['browser_history'][nombre][idx] = valor

    hist['summary'][args.fecha] = s
    hist['per_date_vulns'][args.fecha] = vdia
    hist['per_date_combos'][args.fecha] = combos_unicos(mt)

    print('Guardando histórico...')
    hist_a_guardar = json.loads(json.dumps(hist))
    hist_a_guardar['summary'][args.fecha] = {k: v for k, v in s.items() if k != 'machines_all'}
    with open(args.historico, 'w', encoding='utf-8') as f:
        json.dump(hist_a_guardar, f, ensure_ascii=False)

    print('Generando HTML final...')
    with open(args.template, 'r', encoding='utf-8') as f:
        content = f.read()

    for name, value in [
        ('FECHAS', hist['fechas']),
        ('PER_DATE_VULNS', hist['per_date_vulns']),
        ('PER_DATE_COMBOS', hist['per_date_combos']),
        ('VULN_DETAIL', vdet),
        ('HISTORY', hist['history']),
        ('BROWSER_HISTORY', hist['browser_history']),
        ('SUMMARY', hist['summary']),
    ]:
        _, span = extraer_const(content, name)
        nuevo_json = json.dumps(value, ensure_ascii=False)
        content = content[:span[0]] + nuevo_json + content[span[1]:]

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(content)

    print(f'Listo: {args.out}')
    print(f"Máquinas: {s['machines_total']} | Vulns: {s['vulns_total']} | Overdue: {s['overdue_total']} | Titulos: {s['titles_unique']}")
    print(f"Chrome hoy: {chrome_hoy} | Edge hoy: {edge_hoy}")


if __name__ == '__main__':
    sys.exit(main())
