r"""
Detección de "vulnerabilidades zombi": software que no deja de aparecer
en el listado, versión tras versión (ej. Chrome cada pocos días), en vez
de quedar resuelto de una vez. Se apoya en el histórico por título que ya
mantiene generar_vulnerabilidades.py.

Se considera "zombi" una familia de software (agrupada igual que en
dashboard_recurrencia_software.html) que en el periodo con histórico:
  - ha tenido --umbral-titulos (por defecto 3) o más títulos/versiones
    DISTINTOS, Y
  - ha estado presente --umbral-pct (por defecto 50) % o más de los días
    con histórico.

Uso:
    python3 generar_zombis.py ..\historico\historico_vulnerabilidades.json 2026-09-03 \
        --out ..\resumenes\vulnerabilidades_zombi_2026-09-03.txt
"""
import argparse
import json
import sys
from collections import defaultdict

from core import nombre_software


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('historico_vulns')
    ap.add_argument('fecha')
    ap.add_argument('--umbral-titulos', type=int, default=8)
    ap.add_argument('--umbral-pct', type=float, default=70)
    ap.add_argument('--out', default='vulnerabilidades_zombi.txt')
    args = ap.parse_args()

    with open(args.historico_vulns, 'r', encoding='utf-8') as f:
        hist = json.load(f)

    fechas = hist['fechas']
    titulos_hist = hist['titulos_hist']  # {titulo: {fecha: maquinas}}

    print(f'Agrupando {len(titulos_hist)} títulos por familia de software...')
    por_familia = defaultdict(lambda: {'titulos': set(), 'dias_presente': set()})
    for titulo, por_fecha in titulos_hist.items():
        familia = nombre_software(titulo)
        p = por_familia[familia]
        p['titulos'].add(titulo)
        for f, m in por_fecha.items():
            if m > 0:
                p['dias_presente'].add(f)

    n_dias_total = len(fechas)
    zombis = []
    for familia, datos in por_familia.items():
        n_titulos = len(datos['titulos'])
        pct_dias = round(100 * len(datos['dias_presente']) / n_dias_total, 1) if n_dias_total else 0
        if n_titulos >= args.umbral_titulos and pct_dias >= args.umbral_pct:
            zombis.append({
                'familia': familia, 'n_titulos': n_titulos, 'pct_dias': pct_dias,
                'titulos_ejemplo': sorted(datos['titulos'])[:5],
            })

    zombis.sort(key=lambda z: (-z['n_titulos'], -z['pct_dias']))

    print(f'{len(zombis)} familia(s) de software detectadas como "zombi" '
          f'(>= {args.umbral_titulos} versiones distintas y >= {args.umbral_pct}% de los días con histórico).')

    lineas = [
        f'VULNERABILIDADES ZOMBI · EUT Vulnes · {args.fecha}',
        f'(software con {args.umbral_titulos}+ versiones distintas en el histórico, '
        f'presente en {args.umbral_pct}%+ de los {n_dias_total} días registrados)',
        '=' * 70,
        '',
    ]
    if not zombis:
        lineas.append('Ninguna familia de software cumple el criterio todavía.')
    for z in zombis:
        lineas.append(f"- {z['familia']}: {z['n_titulos']} versiones distintas, "
                       f"presente el {z['pct_dias']}% de los días")
        for t in z['titulos_ejemplo']:
            lineas.append(f"    · {t}")
        if len(z['titulos_ejemplo']) < z['n_titulos']:
            lineas.append(f"    · ... y {z['n_titulos'] - len(z['titulos_ejemplo'])} más")
        lineas.append('')

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lineas))

    print('Listo:', args.out)


if __name__ == '__main__':
    sys.exit(main())
