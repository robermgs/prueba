r"""
Limpieza automática de Estado_vulnes_1.csv: mueve a un fichero de archivo
(estado_vulnes_archivado.csv) las filas cuya vulnerabilidad YA NO aparece
en absoluto en el CSV de hoy (ni en SGTO ni en SANTEC) — es decir, que se
ha arreglado del todo y ya no hace falta seguir haciéndole seguimiento
manual. Así Estado_vulnes_1.csv no crece sin límite.

No se borra nada de verdad: lo que sale de Estado_vulnes_1.csv se
añade (con la fecha en que se archivó) a estado_vulnes_archivado.csv,
así que si hace falta consultarlo luego, sigue estando.

Uso:
    python3 limpiar_estado_vulnes.py SA.csv SG.csv Estado_vulnes_1.csv 2026-09-03 \
        --archivo ..\historico\estado_vulnes_archivado.csv
"""
import argparse
import csv
import sys

from core import cargar_datos, ultima_fecha_estado


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('sa_csv')
    ap.add_argument('sg_csv')
    ap.add_argument('estados_csv')
    ap.add_argument('fecha')
    ap.add_argument('--archivo', default='estado_vulnes_archivado.csv')
    args = ap.parse_args()

    print('Cargando CSV de hoy...')
    filas = cargar_datos(args.sa_csv, args.sg_csv)
    titulos_hoy = set(r['Title'] for r in filas)

    print('Leyendo Estado_vulnes_1.csv...')
    with open(args.estados_csv, 'r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        campos = reader.fieldnames
        filas_estado = list(reader)

    activas = [r for r in filas_estado if r['Title'] in titulos_hoy]
    para_archivar = [r for r in filas_estado if r['Title'] not in titulos_hoy]

    # Ordenar las activas por última fecha de actualización: las más
    # antiguas (o sin ninguna fecha reconocible) van arriba, para verlas
    # de un vistazo en Excel sin tener que abrir el informe aparte.
    def clave_orden(r):
        ult = ultima_fecha_estado(r.get('Historial', ''), r.get('Estado', ''))
        return (ult is not None, ult)  # sin fecha primero, luego de más antigua a más reciente

    activas.sort(key=clave_orden)

    print(f'{len(filas_estado)} vulnerabilidad(es) en seguimiento | '
          f'{len(activas)} siguen activas | {len(para_archivar)} ya no aparecen hoy (se archivan)')

    if not para_archivar:
        print('Nada que archivar hoy.')
        return 0

    # Añadir al archivo (creándolo si no existe, con cabecera)
    try:
        with open(args.archivo, 'r', encoding='utf-8-sig', newline='') as f:
            ya_existe = True
    except FileNotFoundError:
        ya_existe = False

    with open(args.archivo, 'a', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=campos + ['Fecha_Archivado'])
        if not ya_existe:
            w.writeheader()
        for r in para_archivar:
            fila = dict(r)
            fila['Fecha_Archivado'] = args.fecha
            w.writerow(fila)

    # Reescribir Estado_vulnes_1.csv solo con las activas
    with open(args.estados_csv, 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=campos)
        w.writeheader()
        for r in activas:
            w.writerow(r)

    print('Listo:')
    print(f'  {args.estados_csv} actualizado ({len(activas)} filas activas)')
    print(f'  {args.archivo} ampliado (+{len(para_archivar)} filas archivadas)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
