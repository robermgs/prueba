r"""
Busca en una carpeta los ficheros con el nombre que usa tu export
(20260902_Critical_SANTEC.csv / 20260902_Critical_SGTO.csv), y los copia
como SA.csv/SG.csv en esa misma carpeta para que el resto de scripts los
puedan usar sin que tengas que renombrarlos a mano.

Si no le pasas fecha, coge automáticamente el par MÁS RECIENTE que
encuentre. Si le pasas una fecha, busca justo esa.

Imprime SOLO la fecha detectada (YYYY-MM-DD) en la última línea de la
salida estándar, para que run_diario.bat pueda capturarla.

Uso:
    python3 preparar_csv_dia.py ..\csv_diarios
    python3 preparar_csv_dia.py ..\csv_diarios --fecha 2026-09-02
"""
import argparse
import glob
import os
import re
import shutil
import sys

PATRON = re.compile(r'(\d{8})_Critical_(SGTO|SANTEC)\.csv$', re.IGNORECASE)


def encontrar_pares(carpeta):
    pares = {}
    for path in glob.glob(os.path.join(carpeta, '*.csv')):
        m = PATRON.search(os.path.basename(path))
        if not m:
            continue
        yyyymmdd, entorno = m.group(1), m.group(2).upper()
        fecha = f'{yyyymmdd[0:4]}-{yyyymmdd[4:6]}-{yyyymmdd[6:8]}'
        pares.setdefault(fecha, {})[entorno] = path
    return pares


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('carpeta')
    ap.add_argument('--fecha', default=None)
    args = ap.parse_args()

    pares = encontrar_pares(args.carpeta)
    completos = {f: v for f, v in pares.items() if 'SGTO' in v and 'SANTEC' in v}

    if not completos:
        print('ERROR: no he encontrado ningún par SGTO+SANTEC con el nombre '
              'YYYYMMDD_Critical_SGTO.csv / YYYYMMDD_Critical_SANTEC.csv en', args.carpeta,
              file=sys.stderr)
        return 1

    if args.fecha:
        if args.fecha not in completos:
            print(f'ERROR: no encuentro los ficheros de la fecha {args.fecha} en {args.carpeta}',
                  file=sys.stderr)
            return 1
        fecha = args.fecha
    else:
        fecha = sorted(completos.keys())[-1]  # la más reciente

    shutil.copyfile(completos[fecha]['SANTEC'], os.path.join(args.carpeta, 'SA.csv'))
    shutil.copyfile(completos[fecha]['SGTO'], os.path.join(args.carpeta, 'SG.csv'))

    print(f'Detectados y copiados los CSV de {fecha}:', file=sys.stderr)
    print(f'  SANTEC: {os.path.basename(completos[fecha]["SANTEC"])} -> SA.csv', file=sys.stderr)
    print(f'  SGTO:   {os.path.basename(completos[fecha]["SGTO"])} -> SG.csv', file=sys.stderr)

    # Esta es la ÚNICA línea que va a stdout, para que el .bat la capture limpia
    print(fecha)
    return 0


if __name__ == '__main__':
    sys.exit(main())
