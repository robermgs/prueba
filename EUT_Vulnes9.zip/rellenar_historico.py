r"""
Rellena el histórico de dashboard_bruto.html y el cruce de "fixed" hacia
atrás, procesando en orden cronológico todos los CSV antiguos que tengas
guardados.

Espera que los ficheros se llamen así (el formato que usa tu export):
    20260902_Critical_SGTO.csv
    20260902_Critical_SANTEC.csv

Los busca todos en la carpeta que le indiques, detecta la fecha por el
nombre del fichero, y por cada fecha (de la más antigua a la más
reciente) ejecuta generar_bruto.py y generar_resumen_fixed.py con esa
fecha real — así, cuando llegues al día de hoy, ya tendrás variación
calculada en vez de tener que esperar a "mañana".

Uso (desde la carpeta scripts/):
    python3 rellenar_historico.py ..\csv_antiguos ^
        --historico-bruto ..\historico\historico_bruto.json ^
        --snapshot-fixed ..\historico\snapshot_vulnes.json ^
        --dashboards ..\dashboards ^
        --resumenes ..\resumenes

No hace falta que borres nada antes de lanzarlo: si una fecha ya está en
el histórico, simplemente se recalcula (no se duplica).
"""
import argparse
import glob
import os
import re
import subprocess
import sys

PATRON = re.compile(r'(\d{8})_Critical_(SGTO|SANTEC)\.csv$', re.IGNORECASE)


def encontrar_pares(carpeta):
    """Devuelve {fecha 'YYYY-MM-DD': {'SGTO': path, 'SANTEC': path}}."""
    pares = {}
    for path in glob.glob(os.path.join(carpeta, '*.csv')):
        m = PATRON.search(os.path.basename(path))
        if not m:
            continue
        yyyymmdd, entorno = m.group(1), m.group(2).upper()
        fecha = f'{yyyymmdd[0:4]}-{yyyymmdd[4:6]}-{yyyymmdd[6:8]}'
        pares.setdefault(fecha, {})[entorno] = path
    return pares


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('carpeta', help='Carpeta donde están los CSV antiguos')
    ap.add_argument('--historico-bruto', default='historico_bruto.json')
    ap.add_argument('--snapshot-fixed', default='snapshot_vulnes.json')
    ap.add_argument('--dashboards', default='.')
    ap.add_argument('--resumenes', default='.')
    args = ap.parse_args()

    pares = encontrar_pares(args.carpeta)
    fechas = sorted(f for f, v in pares.items() if 'SGTO' in v and 'SANTEC' in v)
    incompletas = sorted(f for f, v in pares.items() if not ('SGTO' in v and 'SANTEC' in v))

    if incompletas:
        print('Aviso: estas fechas solo tienen uno de los dos ficheros y se van a saltar:')
        for f in incompletas:
            print('  -', f, list(pares[f].keys()))

    if not fechas:
        print('No he encontrado ningún par SGTO+SANTEC completo en', args.carpeta)
        return 1

    print(f'Voy a procesar {len(fechas)} fecha(s), de {fechas[0]} a {fechas[-1]}.\n')

    aqui = os.path.dirname(os.path.abspath(__file__))

    for fecha in fechas:
        sa = pares[fecha]['SANTEC']
        sg = pares[fecha]['SGTO']
        print(f'=== {fecha} ===')

        r1 = subprocess.run([
            sys.executable, os.path.join(aqui, 'generar_bruto.py'), sa, sg, fecha,
            '--historico', args.historico_bruto,
            '--out', os.path.join(args.dashboards, 'dashboard_bruto.html'),
        ])
        if r1.returncode != 0:
            print(f'  *** Fallo en generar_bruto.py para {fecha}, sigo con la siguiente fecha ***')

        r2 = subprocess.run([
            sys.executable, os.path.join(aqui, 'generar_resumen_fixed.py'), sa, sg, fecha,
            '--snapshot', args.snapshot_fixed,
            '--out-maquinas', os.path.join(args.resumenes, f'resumen_maquinas_fixed_{fecha}.csv'),
            '--out-vulnes', os.path.join(args.resumenes, f'resumen_vulnes_fixed_{fecha}.csv'),
        ])
        if r2.returncode != 0:
            print(f'  *** Fallo en generar_resumen_fixed.py para {fecha}, sigo con la siguiente fecha ***')

        print()

    print('Listo. Histórico rellenado hasta', fechas[-1])
    print('El dashboard_bruto.html y los ficheros de fixed que han quedado en disco '
          'corresponden a esa última fecha procesada.')


if __name__ == '__main__':
    sys.exit(main())
