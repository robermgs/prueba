r"""
Sustituye "Sergio José Rodríguez Rial" por "Roberto Garcia Villaverde" en
el pie de "Informe generado por..." que aparece en los PDF/CSV exportados
desde los paneles. Es texto fijo (no se regenera cada día), así que con
ejecutar esto UNA VEZ sobre tus ficheros actuales queda arreglado para
siempre — no hace falta tocar ningún generador.

Uso (desde la carpeta scripts/, apuntando a tu carpeta dashboards/):
    python3 renombrar_autor.py ..\dashboards
"""
import glob
import os
import sys

ANTES = 'Sergio José Rodríguez Rial'
DESPUES = 'Roberto Garcia Villaverde'


def main():
    carpeta = sys.argv[1] if len(sys.argv) > 1 else '.'
    tocados = 0
    for path in glob.glob(os.path.join(carpeta, '*.html')):
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        if ANTES not in content:
            continue
        content = content.replace(ANTES, DESPUES)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        print('Arreglado:', os.path.basename(path))
        tocados += 1
    print(f'\nListo. {tocados} fichero(s) modificado(s).')


if __name__ == '__main__':
    main()
