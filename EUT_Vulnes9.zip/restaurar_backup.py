r"""
Lista los backups disponibles (hechos por backup_historico.py) y restaura
el que elijas, volviendo a dejar el histórico y los CSV manuales tal
como estaban en ese momento.

Uso:
    python3 restaurar_backup.py ..\historico ..\csv_diarios
    (te enseña la lista y te pregunta cuál restaurar)

    python3 restaurar_backup.py ..\historico ..\csv_diarios --backup backup_2026-09-02_083015.zip
    (restaura directamente ese, sin preguntar)
"""
import argparse
import glob
import os
import sys
import zipfile


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('carpeta_historico')
    ap.add_argument('carpeta_csv')
    ap.add_argument('--backup', default=None, help='Nombre del fichero de backup a restaurar (si no se indica, se pregunta)')
    args = ap.parse_args()

    carpeta_backups = os.path.join(args.carpeta_historico, 'backups')
    backups = sorted(glob.glob(os.path.join(carpeta_backups, 'backup_*.zip')))

    if not backups:
        print('No hay ningún backup guardado todavía en', carpeta_backups)
        return 1

    if args.backup:
        elegido = os.path.join(carpeta_backups, args.backup)
        if not os.path.exists(elegido):
            print('No existe ese backup:', elegido)
            return 1
    else:
        print('Backups disponibles (del más antiguo al más reciente):')
        for i, b in enumerate(backups, 1):
            print(f'  {i}. {os.path.basename(b)}')
        try:
            n = int(input('\n¿Cuál quieres restaurar? (número): '))
            elegido = backups[n - 1]
        except (ValueError, IndexError):
            print('Selección no válida. No se ha restaurado nada.')
            return 1

    print(f'\nEsto va a SOBRESCRIBIR tu historico\\ y tus Estado_vulnes_1.csv/Equipos_VIP.csv '
          f'actuales con lo que había en {os.path.basename(elegido)}.')
    confirmar = input('¿Seguro? (escribe SI para confirmar): ')
    if confirmar.strip().upper() != 'SI':
        print('Cancelado, no se ha tocado nada.')
        return 0

    with zipfile.ZipFile(elegido, 'r') as z:
        for nombre in z.namelist():
            if nombre.startswith('historico/'):
                destino = os.path.join(args.carpeta_historico, os.path.basename(nombre))
            elif nombre.startswith('csv_diarios/'):
                destino = os.path.join(args.carpeta_csv, os.path.basename(nombre))
            else:
                continue
            with z.open(nombre) as origen, open(destino, 'wb') as f:
                f.write(origen.read())
            print('Restaurado:', destino)

    print('\nListo. Vuelve a ejecutar run_diario.bat para regenerar los paneles con estos datos.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
