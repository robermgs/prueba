r"""
Rotación de la carpeta resumenes\: los ficheros con más de --dias-retener
días (por defecto 60) se comprimen en un ZIP mensual dentro de
resumenes\archivo\ (uno por mes, ej. resumenes_2026-07.zip) y se borran
de la carpeta activa. No se pierde nada, solo se queda menos "suelto".

Detecta la fecha de cada fichero por su propio nombre (busca un
YYYY-MM-DD en el nombre, que es como los nombra todo lo demás de esta
herramienta). Los ficheros sin fecha reconocible en el nombre no se
tocan.

Uso:
    python3 rotar_resumenes.py ..\resumenes 2026-09-03 --dias-retener 60
"""
import argparse
import os
import re
import sys
import zipfile
from datetime import datetime, timedelta

PATRON_FECHA = re.compile(r'(\d{4}-\d{2}-\d{2})')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('carpeta')
    ap.add_argument('fecha_hoy')
    ap.add_argument('--dias-retener', type=int, default=60)
    ap.add_argument('--carpeta-archivo', default=None)
    args = ap.parse_args()

    carpeta_archivo = args.carpeta_archivo or os.path.join(args.carpeta, 'archivo')
    os.makedirs(carpeta_archivo, exist_ok=True)

    hoy = datetime.strptime(args.fecha_hoy, '%Y-%m-%d')
    cutoff = hoy - timedelta(days=args.dias_retener)

    candidatos = []
    for nombre in os.listdir(args.carpeta):
        ruta = os.path.join(args.carpeta, nombre)
        if not os.path.isfile(ruta):
            continue
        m = PATRON_FECHA.search(nombre)
        if not m:
            continue
        try:
            fecha_fichero = datetime.strptime(m.group(1), '%Y-%m-%d')
        except ValueError:
            continue
        if fecha_fichero < cutoff:
            candidatos.append((nombre, ruta, fecha_fichero))

    if not candidatos:
        print(f'Nada que archivar (todo tiene menos de {args.dias_retener} días).')
        return 0

    print(f'{len(candidatos)} fichero(s) con más de {args.dias_retener} días — archivando...')

    por_mes = {}
    for nombre, ruta, fecha_fichero in candidatos:
        clave_mes = fecha_fichero.strftime('%Y-%m')
        por_mes.setdefault(clave_mes, []).append((nombre, ruta))

    for mes, ficheros in por_mes.items():
        zip_path = os.path.join(carpeta_archivo, f'resumenes_{mes}.zip')
        modo = 'a' if os.path.exists(zip_path) else 'w'
        with zipfile.ZipFile(zip_path, modo, zipfile.ZIP_DEFLATED) as z:
            existentes = set(z.namelist()) if modo == 'a' else set()
            for nombre, ruta in ficheros:
                if nombre not in existentes:
                    z.write(ruta, arcname=nombre)
        for nombre, ruta in ficheros:
            os.remove(ruta)
        print(f'  {mes}: {len(ficheros)} fichero(s) -> {zip_path}')

    print('Listo.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
