@echo off
REM ============================================================
REM  run_diario.bat - Actualiza todos los paneles de EUT Vulnes
REM  Uso:  run_diario.bat 2026-09-03
REM  (si no pones fecha, se detecta sola: primero mira si hay CSV
REM   con nombre YYYYMMDD_Critical_SANTEC/SGTO.csv en csv_diarios,
REM   y si no encuentra ninguno, usa la fecha de hoy del sistema)
REM
REM  Toda la orquestacion (que paneles se generan, en que orden, y
REM  el resumen final de que ha ido bien/mal) esta en orquestador.py
REM  -- este .bat solo lo llama.
REM ============================================================

cd /d %~dp0

python orquestador.py %1

echo.
start "" "%~dp0..\dashboards\base.html"

pause
